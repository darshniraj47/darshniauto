<div align="center">

# 🚀 AI Roadmap Generator

### AI-Powered Personalized Career Roadmap Platform

Generate intelligent and structured learning roadmaps using AI.

<p align="center">
  <a href="https://ai-roadmap-generator-ten.vercel.app/">
    <img src="https://img.shields.io/badge/Live-Demo-black?style=for-the-badge&logo=vercel">
  </a>
  
  <a href="https://github.com/cyrilchris-j/airoadgen">
    <img src="https://img.shields.io/badge/GitHub-Repository-black?style=for-the-badge&logo=github">
  </a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Next.js-Framework-black?logo=next.js">
  <img src="https://img.shields.io/badge/React-Frontend-blue?logo=react">
  <img src="https://img.shields.io/badge/TailwindCSS-Styling-38B2AC?logo=tailwind-css">
  <img src="https://img.shields.io/badge/TypeScript-Language-3178C6?logo=typescript">
  <img src="https://img.shields.io/badge/Vercel-Deployment-black?logo=vercel">
</p>

</div>

---

# 📌 Overview

AI Roadmap Generator is a modern AI-powered web application that generates personalized learning and career roadmaps based on user goals, interests, and skill levels.

The platform helps students, developers, and tech enthusiasts create structured growth paths with AI-generated milestones, learning sequences, and skill recommendations.

---

# ✨ Features

- 🤖 AI-powered roadmap generation
- 📚 Personalized learning paths
- ⚡ Fast and responsive UI
- 🎯 Goal-based recommendations
- 📱 Mobile-friendly design
- 🌐 Real-time roadmap rendering
- 🚀 Production deployment with Vercel
- 🎨 Clean modern interface

---

# 🧠 Problem Statement

Many learners struggle with:
- choosing the right technologies
- understanding learning order
- creating structured plans
- tracking skill progression

This project solves that problem by generating customized AI-driven roadmaps instantly.

---

# 🛠 Tech Stack

| Category | Technologies |
|---|---|
| Frontend | Next.js, React.js |
| Styling | Tailwind CSS |
| Language | TypeScript |
| AI Integration | OpenAI API / AI SDK |
| Deployment | Vercel |
| Version Control | Git & GitHub |

---

# 🏗 Architecture

```text
User Input
    ↓
AI Prompt Processing
    ↓
Roadmap Generation Engine
    ↓
Structured Learning Plan
    ↓
Interactive UI Rendering
```

---

# ⚙️ Installation

## 1️⃣ Clone Repository

```bash
git clone https://github.com/cyrilchris-j/airoadgen.git
```

---

## 2️⃣ Navigate to Project

```bash
cd airoadgen
```

---

## 3️⃣ Install Dependencies

```bash
npm install
```

---

## 4️⃣ Start Development Server

```bash
npm run dev
```

---

# 🌐 Live Demo

## 🔗 Website

https://ai-roadmap-generator-ten.vercel.app/

---

# 📂 Folder Structure

```bash
airoadgen/
│
├── app/
├── components/
├── public/
├── styles/
├── lib/
├── utils/
├── package.json
├── tailwind.config.js
└── README.md
```

---

# 🚀 How It Works

### Step 1
User enters:
- career goal
- technology
- learning interest

### Step 2
AI analyzes the prompt.

### Step 3
The system generates:
- roadmap stages
- learning sequence
- milestones
- skill recommendations

### Step 4
Results are displayed in an interactive UI.

---

# 📈 Future Improvements

- 🔐 Authentication system
- 💾 Save generated roadmaps
- 📄 Export roadmap as PDF
- 📊 Progress tracking
- 🤖 AI mentor assistant
- 🌍 Multi-language support
- 🔗 Shareable roadmap links

---

# 🎯 Key Highlights

- Built a production-ready AI application
- Implemented scalable frontend architecture
- Applied prompt engineering concepts
- Designed recruiter-focused UI
- Optimized for responsiveness and usability

---

# 📊 Project Value

| Area | Impact |
|---|---|
| Real-world usability | High |
| AI integration | Strong |
| UI/UX quality | Modern |
| Recruiter appeal | Excellent |
| Portfolio strength | High |

---

# 👨‍💻 Author

## Cyril Christopher

### GitHub
https://github.com/cyrilchris-j

---

# ⭐ Support

If you found this project useful, consider giving it a ⭐ on GitHub.

---

# 📜 License

This project is licensed under the MIT License.
