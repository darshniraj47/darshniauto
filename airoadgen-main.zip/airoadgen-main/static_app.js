/**
 * AI ARCHITECT - VANILLA JAVASCRIPT CORE
 * Optimized for high performance and premium interactions.
 */

const CONFIG = {
    LOCAL_STORAGE_KEYS: {
        USER_DATA: 'architect_user_data',
        ROADMAP_DATA: 'architect_roadmap_data',
        PROGRESS_DATA: 'architect_progress_data'
    }
};

// --- DATA LIBRARIES ---
const CAREER_CATEGORIES = {
    'Tech & Engineering': ['Frontend Developer', 'Backend Developer', 'Full-Stack Developer', 'Mobile App Developer', 'AI / ML Engineer', 'Data Scientist', 'Data Analyst', 'Cybersecurity Analyst', 'Cloud Engineer', 'DevOps Engineer', 'Blockchain Developer', 'Game Developer', 'UI / UX Designer', 'QA / Automation Engineer'],
    'Business & Management': ['Business Analyst', 'Product Manager', 'Project Manager', 'Digital Marketing', 'SEO Specialist', 'Growth Marketer', 'Sales & CRM', 'Entrepreneurship / Startup Founder'],
    'Creative & Media': ['Graphic Designer', 'Motion Designer', 'Video Editor', 'Content Creator', 'Copywriter', 'Social Media Manager', 'Animator'],
    'Core & Professional': ['Mechanical Engineer', 'Electrical Engineer', 'Civil Engineer', 'Architecture', 'Finance & Accounting', 'Banking & Investment', 'Stock Market / Trading', 'HR & Talent Management'],
    'Student & Exam Paths': ['College Student (CSE)', 'College Student (IT)', 'College Student (ECE)', 'College Student (MECH)', 'College Student (CIVIL)', 'School Student (10th)', 'School Student (12th)', 'GATE Preparation', 'UPSC Preparation', 'CAT Preparation', 'GRE Preparation', 'IELTS Preparation']
};

// Curriculum Library (Ported from App.jsx)
const CURRICULUM_LIBRARY = {
    'Frontend Developer': [
        { focus: 'Unit 1: Semantic HTML5 & Accessibility', topics: ['W3C Standards', 'ARIA Roles', 'Semantic Architecture'], link: 'https://developer.mozilla.org/en-US/docs/Learn/HTML' },
        { focus: 'Unit 2: CSS Grid & Layout Systems', topics: ['CSS Grid Masterclass', 'Flexbox Patterns', 'CSS Variables'], link: 'https://web.dev/learn/css/' },
        { focus: 'Unit 3: Modern JS (ES6+) Foundations', topics: ['Execution Context', 'Closures & Scope', 'Async/Await'], link: 'https://javascript.info/' },
        { focus: 'Unit 4: React Component Architecture', topics: ['Virtual DOM', 'JSX Deep Dive', 'Component Lifecycle'], link: 'https://react.dev/learn' },
        { focus: 'Unit 5: Advanced State Orchestration', topics: ['React Hooks Ecosystem', 'Context API', 'State Machines'], link: 'https://react.dev/reference/react' },
        { focus: 'Unit 6: Client-Side Routing & Navigation', topics: ['React Router v7', 'Dynamic Route Guards', 'Data Fetching'], link: 'https://reactrouter.com/en/main' },
        { focus: 'Unit 7: UI Frameworks & Tailwind JIT', topics: ['Utility-First Design', 'Custom Config', 'Theme Design'], link: 'https://tailwindcss.com/docs' },
        { focus: 'Unit 8: API Integration & Data Sync', topics: ['SWR/TanStack Query', 'Optimistic Updates', 'Error Boundaries'], link: 'https://tanstack.com/query/latest' },
        { focus: 'Unit 9: Testing & Quality Assurance', topics: ['Vitest', 'Testing Library', 'E2E with Playwright'], link: 'https://vitest.dev/guide/' },
        { focus: 'Unit 10: Performance Engineering', topics: ['Bundle Analysis', 'Code Splitting', 'Image Optimization'], link: 'https://web.dev/vitals/' },
        { focus: 'Unit 11: Build Tools & Deployment', topics: ['Vite Configuration', 'CI/CD Pipelines', 'Edge Deployment'], link: 'https://vitejs.dev/guide/' },
        { focus: 'Unit 12: SEO & Meta Strategies', topics: ['Open Graph Logic', 'Schema.org', 'Server Components'], link: 'https://nextjs.org/docs/advanced-features/seo-optimization' }
    ],
    // ... Additional field data can be populated here or fetched
};

const SECTOR_DEFAULTS = {
    'Tech & Engineering': [
        { focus: 'Industry Foundations', topics: ['System Principles', 'Core Terminology', 'Environment Setup'], link: 'https://roadmap.sh/' },
        // ... Repeated for 12 units
    ]
};

class AIArchitect {
    constructor() {
        this.appEl = document.getElementById('app');
        this.state = {
            currentView: 'welcome',
            activeTab: 'overview',
            onboardingStep: 1,
            userData: null,
            roadmapData: null,
            progressData: {
                streak: 0,
                tasksCompleted: 0,
                xp: 0,
                level: 1,
                completionPercentage: 0,
                weeklyProgress: [0, 0, 0, 0, 0, 0, 0]
            }
        };

        this.init();
    }

    init() {
        this.loadState();
        this.render();
    }

    loadState() {
        const savedUser = localStorage.getItem(CONFIG.LOCAL_STORAGE_KEYS.USER_DATA);
        const savedRoadmap = localStorage.getItem(CONFIG.LOCAL_STORAGE_KEYS.ROADMAP_DATA);
        const savedProgress = localStorage.getItem(CONFIG.LOCAL_STORAGE_KEYS.PROGRESS_DATA);

        if (savedUser) {
            this.state.userData = JSON.parse(savedUser);
            this.state.currentView = 'dashboard';
        }
        if (savedRoadmap) this.state.roadmapData = JSON.parse(savedRoadmap);
        if (savedProgress) this.state.progressData = JSON.parse(savedProgress);
    }

    saveState() {
        localStorage.setItem(CONFIG.LOCAL_STORAGE_KEYS.USER_DATA, JSON.stringify(this.state.userData));
        localStorage.setItem(CONFIG.LOCAL_STORAGE_KEYS.ROADMAP_DATA, JSON.stringify(this.state.roadmapData));
        localStorage.setItem(CONFIG.LOCAL_STORAGE_KEYS.PROGRESS_DATA, JSON.stringify(this.state.progressData));
    }

    setState(update) {
        Object.assign(this.state, update);
        this.saveState();
        this.render();
    }

    render() {
        this.appEl.innerHTML = '';
        switch (this.state.currentView) {
            case 'welcome': this.renderWelcome(); break;
            case 'onboarding': this.renderOnboarding(); break;
            case 'dashboard': this.renderDashboard(); break;
        }
    }

    // --- TEMPLATES ---
    renderWelcome() {
        const container = document.createElement('div');
        container.className = 'welcome-view animate-fade-in';
        container.innerHTML = `
            <div class="welcome-content">
                <div class="welcome-icon">✧</div>
                <h1 class="welcome-title">AI <span class="text-gradient">ARCHITECT</span></h1>
                <p class="welcome-subtitle">Professional Strategic Roadmap Orchestration System</p>
                <div style="margin-top: 3rem;">
                    <button class="btn-premium" id="startBtn">INITIALIZE PROTOCOL</button>
                </div>
            </div>
        `;
        this.appEl.appendChild(container);
        document.getElementById('startBtn').onclick = () => this.setState({ currentView: 'onboarding' });
    }

    renderOnboarding() {
        const step = this.state.onboardingStep;
        const container = document.createElement('div');
        container.className = 'onboarding-view animate-fade-in';

        let html = '';
        if (step === 1) {
            html = `
                <h2>IDENTIFICATION</h2>
                <p class="form-label" style="margin-bottom: 2rem;">WHO IS ACCESSING THE SYSTEM?</p>
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" id="nameInput" class="input-field" placeholder="Enter name...">
                </div>
                <button class="btn-premium" id="nextBtn">CONTINUE</button>
            `;
        } else if (step === 2) {
            html = `
                <h2>GENESIS DATA</h2>
                <div class="form-group">
                    <label class="form-label">Sector</label>
                    <select id="catSelect" class="input-field">
                        ${Object.keys(CAREER_CATEGORIES).map(c => `<option value="${c}">${c}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Specialization</label>
                    <input type="text" id="fieldInput" class="input-field" placeholder="e.g. Frontend Developer">
                </div>
                <div style="display: flex; gap: 1rem;">
                    <button class="btn-premium" style="background:transparent; color:white; border:1px solid #333" id="backBtn">BACK</button>
                    <button class="btn-premium" id="genBtn">GENERATE SYSTEM</button>
                </div>
            `;
        }

        container.innerHTML = `<div class="onboarding-card">${html}</div>`;
        this.appEl.appendChild(container);

        if (step === 1) {
            document.getElementById('nextBtn').onclick = () => {
                const name = document.getElementById('nameInput').value;
                if (!name) return;
                this.state.userData = { name };
                this.setState({ onboardingStep: 2 });
            };
        } else {
            document.getElementById('backBtn').onclick = () => this.setState({ onboardingStep: 1 });
            document.getElementById('genBtn').onclick = () => {
                const category = document.getElementById('catSelect').value;
                const field = document.getElementById('fieldInput').value;
                if (!field) return;
                this.state.userData = { ...this.state.userData, category, field };
                this.generateRoadmap();
            };
        }
    }

    generateRoadmap() {
        const data = this.state.userData;
        const syllabus = CURRICULUM_LIBRARY[data.field] || SECTOR_DEFAULTS[data.category] || SECTOR_DEFAULTS['Tech & Engineering'];

        this.state.roadmapData = {
            field: data.field,
            monthlyGoals: [
                { month: 1, goal: 'Phase I: Foundations', status: 'active' },
                { month: 2, goal: 'Phase II: Architecture', status: 'upcoming' },
                { month: 3, goal: 'Phase III: Optimization', status: 'upcoming' }
            ],
            weeklyFocus: syllabus.slice(0, 12).map((u, i) => ({ ...u, week: i + 1, status: i === 0 ? 'active' : 'upcoming' })),
            dailyTasks: this.generateMockTasks()
        };
        this.setState({ currentView: 'dashboard' });
    }

    generateMockTasks() {
        // Simple mock task generator for vanilla version
        return Array(7).fill(0).map((_, i) => ({
            day: i + 1,
            date: new Date().toLocaleDateString(),
            tasks: [
                { id: `t${i}-1`, title: 'System Review', duration: 20, completed: false },
                { id: `t${i}-2`, title: 'Core Implementation', duration: 40, completed: false }
            ]
        }));
    }

    renderDashboard() {
        const tab = this.state.activeTab;
        const container = document.createElement('div');
        container.className = 'dashboard-view animate-fade-in';
        container.innerHTML = `
            <nav class="main-nav">
                <div class="nav-wrapper">
                    <div class="nav-brand">✧ ARCHITECT</div>
                    <div class="nav-links">
                        <button class="nav-link ${tab === 'overview' ? 'active' : ''}" data-tab="overview">OVERVIEW</button>
                        <button class="nav-link ${tab === 'tasks' ? 'active' : ''}" data-tab="tasks">OBJECTIVES</button>
                    </div>
                    <button id="resetBtn" class="badge">RESET SYSTEM</button>
                </div>
            </nav>
            <main class="main-content">
                <div class="card">
                    <h2>WELCOME, ${this.state.userData.name.toUpperCase()}</h2>
                    <p style="color: var(--color-text-muted); margin-top: 1rem;">STATUS: OPERATIONAL | MISSION: ${this.state.userData.field.toUpperCase()}</p>
                </div>
            </main>
        `;
        this.appEl.appendChild(container);

        container.querySelectorAll('.nav-link').forEach(btn => {
            btn.onclick = () => this.setState({ activeTab: btn.dataset.tab });
        });
        document.getElementById('resetBtn').onclick = () => {
            if (confirm('RESET ALL DATA?')) {
                localStorage.clear();
                window.location.reload();
            }
        };
    }
}

const app = new AIArchitect();
