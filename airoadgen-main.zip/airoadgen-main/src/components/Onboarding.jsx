import { useState } from 'react';
import './Onboarding.css';

const CAREER_CATEGORIES = {
    'Tech & Engineering': [
        'Frontend Developer',
        'Backend Developer',
        'Full-Stack Developer',
        'Mobile App Developer',
        'AI / ML Engineer',
        'Data Scientist',
        'Data Analyst',
        'Cybersecurity Analyst',
        'Cloud Engineer',
        'DevOps Engineer',
        'Blockchain Developer',
        'Game Developer',
        'UI / UX Designer',
        'QA / Automation Engineer',
    ],
    'Business & Management': [
        'Business Analyst',
        'Product Manager',
        'Project Manager',
        'Digital Marketing',
        'SEO Specialist',
        'Growth Marketer',
        'Sales & CRM',
        'Entrepreneurship / Startup Founder',
    ],
    'Creative & Media': [
        'Graphic Designer',
        'Motion Designer',
        'Video Editor',
        'Content Creator',
        'Copywriter',
        'Social Media Manager',
        'Animator',
    ],
    'Core & Professional': [
        'Mechanical Engineer',
        'Electrical Engineer',
        'Civil Engineer',
        'Architecture',
        'Finance & Accounting',
        'Banking & Investment',
        'Stock Market / Trading',
        'HR & Talent Management',
    ],
    'Student & Exam Paths': [
        'College Student (CSE)',
        'College Student (IT)',
        'College Student (ECE)',
        'College Student (MECH)',
        'College Student (CIVIL)',
        'School Student (10th)',
        'School Student (12th)',
        'GATE Preparation',
        'UPSC Preparation',
        'CAT Preparation',
        'GRE Preparation',
        'IELTS Preparation',
    ],
};

const Onboarding = ({ onComplete }) => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        name: '',
        category: '',
        field: '',
        level: 'Beginner',
        dailyTime: '30',
        duration: '3',
        preference: 'Mixed',
        weakAreas: '',
    });

    const totalSteps = 5;

    const handleChange = (field, value) => {
        setFormData(prev => ({
            ...prev,
            [field]: value,
            // Reset field when category changes
            ...(field === 'category' ? { field: '' } : {}),
        }));
    };

    const handleNext = () => {
        if (step < totalSteps) {
            setStep(step + 1);
        } else {
            onComplete(formData);
        }
    };

    const handleBack = () => {
        if (step > 1) {
            setStep(step - 1);
        }
    };

    const canProceed = () => {
        switch (step) {
            case 1:
                return formData.name.trim().length > 0;
            case 2:
                return formData.category && formData.field;
            case 3:
                return formData.level;
            case 4:
                return formData.dailyTime && formData.duration;
            case 5:
                return formData.preference;
            default:
                return false;
        }
    };

    return (
        <div className="onboarding">
            <div className="container">
                <div className="onboarding-container">
                    {/* Progress Bar */}
                    <div className="progress-bar">
                        <div className="progress-steps">
                            {Array.from({ length: totalSteps }).map((_, index) => (
                                <div
                                    key={index}
                                    className={`progress-step ${index + 1 <= step ? 'active' : ''} ${index + 1 < step ? 'completed' : ''
                                        }`}
                                >
                                    <div className="step-circle">
                                        {index + 1 < step ? (
                                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                <path
                                                    d="M3 8L6 11L13 4"
                                                    stroke="currentColor"
                                                    strokeWidth="2"
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                />
                                            </svg>
                                        ) : (
                                            <span>{index + 1}</span>
                                        )}
                                    </div>
                                    {index < totalSteps - 1 && <div className="step-line"></div>}
                                </div>
                            ))}
                        </div>
                        <div className="progress-label">
                            Step {step} of {totalSteps}
                        </div>
                    </div>

                    {/* Form Card */}
                    <div className="onboarding-card card-glass">
                        {/* Step 1: Personal Info */}
                        {step === 1 && (
                            <div className="form-step animate-slide-in-up">
                                <h2>👋 Welcome! Let's get started</h2>
                                <p className="step-description">What should we call you?</p>

                                <div className="form-group">
                                    <label htmlFor="name">Your Name</label>
                                    <input
                                        id="name"
                                        type="text"
                                        className="input"
                                        placeholder="Enter your name"
                                        value={formData.name}
                                        onChange={(e) => handleChange('name', e.target.value)}
                                        autoFocus
                                    />
                                </div>
                            </div>
                        )}

                        {/* Step 2: Career Selection */}
                        {step === 2 && (
                            <div className="form-step animate-slide-in-up">
                                <h2>🎯 Choose Your Career Path</h2>
                                <p className="step-description">Select your field or career goal</p>

                                <div className="form-group">
                                    <label htmlFor="category">Category</label>
                                    <select
                                        id="category"
                                        className="select"
                                        value={formData.category}
                                        onChange={(e) => handleChange('category', e.target.value)}
                                    >
                                        <option value="">Select a category</option>
                                        {Object.keys(CAREER_CATEGORIES).map((category) => (
                                            <option key={category} value={category}>
                                                {category}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                {formData.category && (
                                    <div className="form-group">
                                        <label htmlFor="field">Specific Field</label>
                                        <select
                                            id="field"
                                            className="select"
                                            value={formData.field}
                                            onChange={(e) => handleChange('field', e.target.value)}
                                        >
                                            <option value="">Select a field</option>
                                            {CAREER_CATEGORIES[formData.category].map((field) => (
                                                <option key={field} value={field}>
                                                    {field}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Step 3: Experience Level */}
                        {step === 3 && (
                            <div className="form-step animate-slide-in-up">
                                <h2>📊 What's Your Current Level?</h2>
                                <p className="step-description">Help us tailor the roadmap to your experience</p>

                                <div className="level-options">
                                    {['Beginner', 'Intermediate', 'Advanced'].map((level) => (
                                        <button
                                            key={level}
                                            className={`level-option ${formData.level === level ? 'selected' : ''}`}
                                            onClick={() => handleChange('level', level)}
                                        >
                                            <div className="level-icon">
                                                {level === 'Beginner' && '🌱'}
                                                {level === 'Intermediate' && '🚀'}
                                                {level === 'Advanced' && '⭐'}
                                            </div>
                                            <div className="level-title">{level}</div>
                                            <div className="level-desc">
                                                {level === 'Beginner' && 'Just starting out'}
                                                {level === 'Intermediate' && 'Some experience'}
                                                {level === 'Advanced' && 'Expert level'}
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Step 4: Time Commitment */}
                        {step === 4 && (
                            <div className="form-step animate-slide-in-up">
                                <h2>⏰ Time Commitment</h2>
                                <p className="step-description">How much time can you dedicate?</p>

                                <div className="form-group">
                                    <label htmlFor="dailyTime">Daily Available Time (minutes)</label>
                                    <div className="time-buttons">
                                        {['10', '20', '30', '60'].map((time) => (
                                            <button
                                                key={time}
                                                className={`time-btn ${formData.dailyTime === time ? 'selected' : ''}`}
                                                onClick={() => handleChange('dailyTime', time)}
                                            >
                                                {time} min
                                            </button>
                                        ))}
                                    </div>
                                    <input
                                        id="dailyTime"
                                        type="number"
                                        className="input"
                                        placeholder="Or enter custom minutes"
                                        value={formData.dailyTime}
                                        onChange={(e) => handleChange('dailyTime', e.target.value)}
                                        min="5"
                                        max="300"
                                    />
                                </div>

                                <div className="form-group">
                                    <label htmlFor="duration">Total Duration (months)</label>
                                    <div className="time-buttons">
                                        {['1', '3', '6', '12'].map((duration) => (
                                            <button
                                                key={duration}
                                                className={`time-btn ${formData.duration === duration ? 'selected' : ''}`}
                                                onClick={() => handleChange('duration', duration)}
                                            >
                                                {duration} {duration === '1' ? 'month' : 'months'}
                                            </button>
                                        ))}
                                    </div>
                                    <input
                                        id="duration"
                                        type="number"
                                        className="input"
                                        placeholder="Or enter custom months"
                                        value={formData.duration}
                                        onChange={(e) => handleChange('duration', e.target.value)}
                                        min="1"
                                        max="24"
                                    />
                                </div>
                            </div>
                        )}

                        {/* Step 5: Learning Preferences */}
                        {step === 5 && (
                            <div className="form-step animate-slide-in-up">
                                <h2>📚 Learning Preferences</h2>
                                <p className="step-description">How do you prefer to learn?</p>

                                <div className="preference-options">
                                    {[
                                        { value: 'Reading', icon: '📖', desc: 'Articles & Documentation' },
                                        { value: 'Videos', icon: '🎥', desc: 'Video Tutorials' },
                                        { value: 'Practice', icon: '💻', desc: 'Hands-on Practice' },
                                        { value: 'Mixed', icon: '🎯', desc: 'Combination of All' },
                                    ].map((pref) => (
                                        <button
                                            key={pref.value}
                                            className={`preference-option ${formData.preference === pref.value ? 'selected' : ''}`}
                                            onClick={() => handleChange('preference', pref.value)}
                                        >
                                            <div className="pref-icon">{pref.icon}</div>
                                            <div className="pref-title">{pref.value}</div>
                                            <div className="pref-desc">{pref.desc}</div>
                                        </button>
                                    ))}
                                </div>

                                <div className="form-group">
                                    <label htmlFor="weakAreas">Weak Areas (Optional)</label>
                                    <textarea
                                        id="weakAreas"
                                        className="input"
                                        placeholder="List topics you find challenging..."
                                        value={formData.weakAreas}
                                        onChange={(e) => handleChange('weakAreas', e.target.value)}
                                        rows="3"
                                    ></textarea>
                                </div>
                            </div>
                        )}

                        {/* Navigation Buttons */}
                        <div className="form-actions">
                            {step > 1 && (
                                <button className="btn btn-ghost" onClick={handleBack}>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path
                                            d="M16 10H4M4 10L10 16M4 10L10 4"
                                            stroke="currentColor"
                                            strokeWidth="2"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        />
                                    </svg>
                                    <span>Back</span>
                                </button>
                            )}

                            <button
                                className="btn btn-primary"
                                onClick={handleNext}
                                disabled={!canProceed()}
                            >
                                <span>{step === totalSteps ? 'Generate Roadmap' : 'Continue'}</span>
                                {step === totalSteps ? (
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path
                                            d="M5 10L8.5 13.5L15 6.5"
                                            stroke="currentColor"
                                            strokeWidth="2"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        />
                                    </svg>
                                ) : (
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path
                                            d="M4 10H16M16 10L10 4M16 10L10 16"
                                            stroke="currentColor"
                                            strokeWidth="2"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        />
                                    </svg>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Onboarding;
