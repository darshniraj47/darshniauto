import './Roadmap.css';

const Roadmap = ({ roadmapData }) => {
    return (
        <div className="roadmap animate-fade-in">
            {/* Monthly Mission Containers */}
            <section className="roadmap-section">
                <h2>🎯 STRATEGIC PHASES</h2>
                <div className="goals-grid">
                    {roadmapData.monthlyGoals.map((goal, index) => (
                        <div
                            key={goal.month}
                            className={`goal-card ${goal.status === 'active' ? 'active' : ''} ${goal.status === 'completed' ? 'completed' : ''}`}
                        >
                            <div className="goal-status-badge">{goal.status.toUpperCase()}</div>
                            <div className="goal-month">PHASE {goal.month}</div>
                            <div className="goal-title">{goal.goal}</div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Structured Syllabus (Grouped by Month) */}
            <section className="roadmap-section">
                <h2>TECHNICAL SYLLABUS — {roadmapData.field.toUpperCase()}</h2>

                {[0, 1, 2].map(monthIndex => {
                    const monthWeeks = roadmapData.weeklyFocus.slice(monthIndex * 4, (monthIndex + 1) * 4);
                    if (monthWeeks.length === 0) return null;

                    return (
                        <div key={monthIndex} className="month-group">
                            <h3 className="month-header">MONTH {monthIndex + 1}: {roadmapData.monthlyGoals[monthIndex]?.goal || 'Advanced Protocol'}</h3>
                            <div className="weeks-grid">
                                {monthWeeks.map((week) => (
                                    <div
                                        key={week.week}
                                        className={`week-card ${week.status === 'active' ? 'active' : ''}`}
                                    >
                                        <div className="week-header">
                                            <div className="week-number">Unit {week.week}</div>
                                            <div className="week-status-tag">
                                                {week.status === 'active' ? 'CURRENT PROTOCOL' : ''}
                                            </div>
                                        </div>
                                        <div className="week-focus">{week.focus}</div>
                                        <div className="week-topics">
                                            {week.topics.map((topic, idx) => (
                                                <div key={idx} className="topic-item">
                                                    <span className="topic-bullet">✧</span>
                                                    <span>{topic}</span>
                                                </div>
                                            ))}
                                        </div>
                                        {week.link && (
                                            <a
                                                href={week.link}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="unit-resource-link"
                                            >
                                                DEEP-LEARNING RESOURCE <span>→</span>
                                            </a>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
            </section>

            {/* Milestones */}
            <section className="roadmap-section">
                <h2>SYSTEM MILESTONES</h2>
                <div className="milestones-container">
                    {roadmapData.milestones.map((milestone) => (
                        <div
                            key={milestone.id}
                            className={`milestone-card ${milestone.status === 'active' ? 'active' : ''
                                }`}
                        >
                            <div className="milestone-icon">
                                {milestone.status === 'completed' ? '✓' : milestone.target + '%'}
                            </div>
                            <div className="milestone-details">
                                <div className="milestone-title">{milestone.title}</div>
                                <div className="milestone-progress">
                                    <div className="progress-track">
                                        <div
                                            className="progress-fill"
                                            style={{ width: `${milestone.target}%` }}
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Project Suggestions */}
            <section className="roadmap-section">
                <h2>SUGGESTED PROJECTS</h2>
                <div className="projects-list">
                    {roadmapData.projects.map((project, index) => (
                        <div key={index} className="project-item">
                            <div className="project-number">{String(index + 1).padStart(2, '0')}</div>
                            <div className="project-title">{project}</div>
                            <button className="btn-roadmap">Deploy</button>
                        </div>
                    ))}
                </div>
            </section>

            {/* Certifications */}
            <section className="roadmap-section">
                <h2>CREDENTIAL TRACK</h2>
                <div className="certifications-list">
                    {roadmapData.certifications.map((cert, index) => (
                        <div key={index} className="cert-item">
                            <div className="cert-icon">✧</div>
                            <div className="cert-title">{cert}</div>
                            <button className="btn-roadmap secondary">Examine</button>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};

export default Roadmap;
