import { useState } from 'react';
import './Dashboard.css';
import DailyTasks from './DailyTasks';
import Progress from './Progress';
import Roadmap from './Roadmap';
import Resources from './Resources';

const Dashboard = ({ userData, roadmapData, progressData, onReset, setProgressData, currentUser, onLogout }) => {
    const [activeTab, setActiveTab] = useState('overview');

    const getMotivationalMessage = () => {
        const { streak } = progressData;
        if (streak === 0) return "Begin your odyssey. 🚀";
        if (streak < 3) return `Momentum building. ${streak} day streak. 🔥`;
        return `Consistent excellence. ${streak} day streak. 🏆`;
    };

    return (
        <div className="dashboard-container">
            {/* Proper Classical Top Navigation */}
            <nav className="main-nav">
                <div className="nav-wrapper">
                    <div className="nav-brand">
                        <span className="brand-icon">✧</span>
                        <span className="brand-text">AI ARCHITECT</span>
                    </div>

                    <div className="nav-links">
                        <button
                            className={`nav-link ${activeTab === 'overview' ? 'active' : ''}`}
                            onClick={() => setActiveTab('overview')}
                        >
                            Overview
                        </button>
                        <button
                            className={`nav-link ${activeTab === 'tasks' ? 'active' : ''}`}
                            onClick={() => setActiveTab('tasks')}
                        >
                            Daily Tasks
                        </button>
                        <button
                            className={`nav-link ${activeTab === 'roadmap' ? 'active' : ''}`}
                            onClick={() => setActiveTab('roadmap')}
                        >
                            Roadmap
                        </button>
                        <button
                            className={`nav-link ${activeTab === 'progress' ? 'active' : ''}`}
                            onClick={() => setActiveTab('progress')}
                        >
                            Analytics
                        </button>
                        <button
                            className={`nav-link ${activeTab === 'resources' ? 'active' : ''}`}
                            onClick={() => setActiveTab('resources')}
                        >
                            Library
                        </button>
                    </div>

                    <div className="nav-actions">
                        {currentUser && (
                            <div className="user-profile">
                                {currentUser.photoURL ? (
                                    <img
                                        src={currentUser.photoURL}
                                        alt="Profile"
                                        className="user-avatar"
                                        referrerPolicy="no-referrer"
                                    />
                                ) : (
                                    <div className="user-avatar-placeholder">
                                        {(currentUser.displayName || currentUser.email || 'U').charAt(0).toUpperCase()}
                                    </div>
                                )}
                                <span className="user-name">
                                    {currentUser.displayName || currentUser.email?.split('@')[0]}
                                </span>
                            </div>
                        )}
                        <button className="btn-classical-sm" onClick={onReset}>
                            Reset
                        </button>
                        {onLogout && (
                            <button className="btn-logout" onClick={onLogout}>
                                Logout
                            </button>
                        )}
                    </div>
                </div>
            </nav>

            <main className="main-content">
                <div className="content-container">
                    {activeTab === 'overview' && (
                        <div className="overview-section animate-fade-in">
                            <header className="section-header">
                                <h1 className="display-title">
                                    Welcome, <span className="text-accent">{userData.name}</span>
                                </h1>
                                <p className="section-subtitle">{getMotivationalMessage()}</p>
                            </header>

                            <div className="stats-header-grid">
                                <div className="classical-stat-card">
                                    <span className="stat-label">STREAK</span>
                                    <span className="stat-value">{progressData.streak}</span>
                                    <span className="stat-unit">DAYS</span>
                                </div>
                                <div className="classical-stat-card">
                                    <span className="stat-label">XP</span>
                                    <span className="stat-value">{progressData.xp}</span>
                                    <span className="stat-unit">TOTAL</span>
                                </div>
                                <div className="classical-stat-card">
                                    <span className="stat-label">LEVEL</span>
                                    <span className="stat-value">{progressData.level}</span>
                                    <span className="stat-unit">RANK</span>
                                </div>
                                <div className="classical-stat-card highlight">
                                    <span className="stat-label">PROGRESS</span>
                                    <span className="stat-value">{progressData.completionPercentage}%</span>
                                    <div className="mini-progress-track">
                                        <div className="mini-progress-fill" style={{ width: `${progressData.completionPercentage}%` }}></div>
                                    </div>
                                </div>
                            </div>

                            <div className="quick-portal-grid">
                                <div className="portal-card" onClick={() => setActiveTab('tasks')}>
                                    <h3>Daily Objectives</h3>
                                    <p>Your current tasks for {userData.field}.</p>
                                    <span className="portal-link">View Tasks →</span>
                                </div>
                                <div className="portal-card" onClick={() => setActiveTab('roadmap')}>
                                    <h3>Project Roadmap</h3>
                                    <p>Comprehensive path to mastery.</p>
                                    <span className="portal-link">Expand Roadmap →</span>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'tasks' && (
                        <DailyTasks
                            roadmapData={roadmapData}
                            progressData={progressData}
                            setProgressData={setProgressData}
                        />
                    )}

                    {activeTab === 'roadmap' && <Roadmap roadmapData={roadmapData} />}
                    {activeTab === 'progress' && <Progress progressData={progressData} />}
                    {activeTab === 'resources' && <Resources userData={userData} />}
                </div>
            </main>

            <footer className="classical-footer">
                <div className="footer-content">
                    <p>&copy; 2026 AI Architect | Professional Learning Systems</p>
                </div>
            </footer>
        </div>
    );
};

export default Dashboard;
