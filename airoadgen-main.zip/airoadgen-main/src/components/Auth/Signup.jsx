import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import './Auth.css';

function Signup({ onSwitchToLogin }) {
    const [displayName, setDisplayName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [isGoogleLoading, setIsGoogleLoading] = useState(false);
    const [localError, setLocalError] = useState('');

    const { signup, loginWithGoogle, error, clearError } = useAuth();

    // Password strength checker
    const getPasswordStrength = (pass) => {
        if (!pass) return null;
        if (pass.length < 6) return 'weak';
        if (pass.length < 8 || !/[A-Z]/.test(pass) || !/[0-9]/.test(pass)) return 'medium';
        return 'strong';
    };

    const passwordStrength = getPasswordStrength(password);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLocalError('');

        // Validation
        if (!displayName.trim()) {
            setLocalError('Please enter your name.');
            return;
        }

        if (!email || !password) {
            setLocalError('Please fill in all fields.');
            return;
        }

        if (password !== confirmPassword) {
            setLocalError('Passwords do not match.');
            return;
        }

        if (password.length < 6) {
            setLocalError('Password must be at least 6 characters.');
            return;
        }

        setIsLoading(true);
        try {
            await signup(email, password, displayName);
            // Success - user will be redirected automatically by AuthContext
        } catch (err) {
            console.error('Signup error:', err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleGoogleSignup = async () => {
        setIsGoogleLoading(true);
        clearError();
        setLocalError('');
        try {
            await loginWithGoogle();
            // Success - user will be redirected automatically by AuthContext
        } catch (err) {
            console.error('Google signup error:', err);
        } finally {
            setIsGoogleLoading(false);
        }
    };

    const handleInputChange = (setter) => (e) => {
        clearError();
        setLocalError('');
        setter(e.target.value);
    };

    const displayError = localError || error;

    return (
        <div className="auth-container">
            <div className="auth-card">
                {/* Header */}
                <div className="auth-header">
                    <div className="auth-logo">
                        <div className="auth-logo-icon">🎯</div>
                        <span className="auth-logo-text">AI Roadmap</span>
                    </div>
                    <h1 className="auth-title">Create Account</h1>
                    <p className="auth-subtitle">Start your personalized learning journey today</p>
                </div>

                {/* Error Message */}
                {displayError && (
                    <div className="auth-error">
                        <span className="auth-error-icon">⚠️</span>
                        <span className="auth-error-text">{displayError}</span>
                    </div>
                )}

                {/* Signup Form */}
                <form className="auth-form" onSubmit={handleSubmit}>
                    {/* Name Input */}
                    <div className="auth-input-group">
                        <label className="auth-input-label">Full Name</label>
                        <div className="auth-input-wrapper">
                            <input
                                type="text"
                                className="auth-input"
                                placeholder="Enter your name"
                                value={displayName}
                                onChange={handleInputChange(setDisplayName)}
                                autoComplete="name"
                                required
                            />
                            <span className="auth-input-icon">👤</span>
                        </div>
                    </div>

                    {/* Email Input */}
                    <div className="auth-input-group">
                        <label className="auth-input-label">Email Address</label>
                        <div className="auth-input-wrapper">
                            <input
                                type="email"
                                className="auth-input"
                                placeholder="you@example.com"
                                value={email}
                                onChange={handleInputChange(setEmail)}
                                autoComplete="email"
                                required
                            />
                            <span className="auth-input-icon">📧</span>
                        </div>
                    </div>

                    {/* Password Input */}
                    <div className="auth-input-group">
                        <label className="auth-input-label">Password</label>
                        <div className="auth-input-wrapper">
                            <input
                                type={showPassword ? 'text' : 'password'}
                                className="auth-input"
                                placeholder="Create a strong password"
                                value={password}
                                onChange={handleInputChange(setPassword)}
                                autoComplete="new-password"
                                required
                            />
                            <span className="auth-input-icon">🔒</span>
                            <button
                                type="button"
                                className="auth-password-toggle"
                                onClick={() => setShowPassword(!showPassword)}
                                tabIndex={-1}
                            >
                                {showPassword ? '🙈' : '👁️'}
                            </button>
                        </div>

                        {/* Password Strength Indicator */}
                        {password && (
                            <div className="password-strength">
                                <div className="password-strength-bar">
                                    <div className={`password-strength-fill ${passwordStrength}`}></div>
                                </div>
                                <span className={`password-strength-text ${passwordStrength}`}>
                                    {passwordStrength === 'weak' && 'Weak - Add more characters'}
                                    {passwordStrength === 'medium' && 'Medium - Try adding numbers & capitals'}
                                    {passwordStrength === 'strong' && 'Strong password ✓'}
                                </span>
                            </div>
                        )}
                    </div>

                    {/* Confirm Password Input */}
                    <div className="auth-input-group">
                        <label className="auth-input-label">Confirm Password</label>
                        <div className="auth-input-wrapper">
                            <input
                                type={showPassword ? 'text' : 'password'}
                                className="auth-input"
                                placeholder="Confirm your password"
                                value={confirmPassword}
                                onChange={handleInputChange(setConfirmPassword)}
                                autoComplete="new-password"
                                required
                            />
                            <span className="auth-input-icon">🔐</span>
                        </div>
                        {confirmPassword && password !== confirmPassword && (
                            <span className="password-strength-text weak" style={{ marginTop: '0.25rem' }}>
                                Passwords don't match
                            </span>
                        )}
                    </div>

                    {/* Submit Button */}
                    <button
                        type="submit"
                        className="auth-submit-btn"
                        disabled={isLoading || !email || !password || !displayName || password !== confirmPassword}
                    >
                        {isLoading ? (
                            <>
                                <div className="auth-spinner"></div>
                                <span>Creating account...</span>
                            </>
                        ) : (
                            <>
                                <span>Create Account</span>
                                <span>→</span>
                            </>
                        )}
                    </button>
                </form>

                {/* Divider */}
                <div className="auth-divider">
                    <div className="auth-divider-line"></div>
                    <span className="auth-divider-text">or</span>
                    <div className="auth-divider-line"></div>
                </div>

                {/* Social Signup */}
                <div className="auth-social-buttons">
                    <button
                        type="button"
                        className="auth-social-btn google"
                        onClick={handleGoogleSignup}
                        disabled={isGoogleLoading}
                    >
                        {isGoogleLoading ? (
                            <>
                                <div className="auth-spinner"></div>
                                <span>Signing up with Google...</span>
                            </>
                        ) : (
                            <>
                                <div className="auth-social-icon">
                                    <svg className="google-icon" viewBox="0 0 24 24">
                                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                                    </svg>
                                </div>
                                <span>Continue with Google</span>
                            </>
                        )}
                    </button>
                </div>

                {/* Footer */}
                <div className="auth-footer">
                    <p className="auth-footer-text">
                        Already have an account?
                        <span className="auth-footer-link" onClick={onSwitchToLogin}>
                            Sign In
                        </span>
                    </p>
                </div>
            </div>
        </div>
    );
}

export default Signup;
