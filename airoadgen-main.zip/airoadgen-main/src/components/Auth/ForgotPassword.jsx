import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import './Auth.css';

function ForgotPassword({ onBack }) {
    const [email, setEmail] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [success, setSuccess] = useState(false);

    const { resetPassword, error, clearError } = useAuth();

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!email) {
            return;
        }

        setIsLoading(true);
        try {
            await resetPassword(email);
            setSuccess(true);
        } catch (err) {
            console.error('Password reset error:', err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (e) => {
        clearError();
        setEmail(e.target.value);
    };

    return (
        <div className="auth-container">
            <div className="auth-card">
                {/* Back Button */}
                <button className="auth-back-btn" onClick={onBack}>
                    <span>←</span>
                    <span>Back to login</span>
                </button>

                {/* Header */}
                <div className="auth-header">
                    <div className="auth-logo">
                        <div className="auth-logo-icon">🔑</div>
                    </div>
                    <h1 className="auth-title">Reset Password</h1>
                    <p className="auth-subtitle">
                        Enter your email address and we'll send you a link to reset your password.
                    </p>
                </div>

                {/* Success Message */}
                {success && (
                    <div className="auth-success">
                        <span className="auth-success-icon">✅</span>
                        <span className="auth-success-text">
                            Password reset email sent! Check your inbox and follow the instructions.
                        </span>
                    </div>
                )}

                {/* Error Message */}
                {error && !success && (
                    <div className="auth-error">
                        <span className="auth-error-icon">⚠️</span>
                        <span className="auth-error-text">{error}</span>
                    </div>
                )}

                {/* Reset Form */}
                {!success && (
                    <form className="auth-form" onSubmit={handleSubmit}>
                        <div className="auth-input-group">
                            <label className="auth-input-label">Email Address</label>
                            <div className="auth-input-wrapper">
                                <input
                                    type="email"
                                    className="auth-input"
                                    placeholder="you@example.com"
                                    value={email}
                                    onChange={handleInputChange}
                                    autoComplete="email"
                                    required
                                />
                                <span className="auth-input-icon">📧</span>
                            </div>
                        </div>

                        <button
                            type="submit"
                            className="auth-submit-btn"
                            disabled={isLoading || !email}
                        >
                            {isLoading ? (
                                <>
                                    <div className="auth-spinner"></div>
                                    <span>Sending reset link...</span>
                                </>
                            ) : (
                                <>
                                    <span>Send Reset Link</span>
                                    <span>→</span>
                                </>
                            )}
                        </button>
                    </form>
                )}

                {/* Footer */}
                {success && (
                    <div className="auth-footer">
                        <button
                            className="auth-submit-btn"
                            onClick={onBack}
                            style={{ marginTop: '1rem' }}
                        >
                            <span>Return to Login</span>
                            <span>→</span>
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}

export default ForgotPassword;
