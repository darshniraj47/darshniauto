import { useState } from 'react';
import './Resources.css';

const Resources = ({ userData }) => {
    const [activeCategory, setActiveCategory] = useState('all');

    const resourcesDatabase = {
        'Frontend Developer': {
            videos: [
                { title: 'Modern JavaScript Full Course', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=modern+javascript+course', duration: '12h' },
                { title: 'Advanced React Patterns', platform: 'Frontend Masters', url: 'https://frontendmasters.com/courses/advanced-react-patterns/', duration: '6h' },
                { title: 'CSS Grid & Flexbox Mastery', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=css+grid+flexbox+mastery', duration: '4h' },
            ],
            articles: [
                { title: 'MDN Web Docs: Learning Web Development', source: 'Mozilla', url: 'https://developer.mozilla.org/en-US/docs/Learn', readTime: 'Self-paced' },
                { title: 'BEM Methodology Guide', source: 'BEM.info', url: 'http://getbem.com/introduction/', readTime: '15 min' },
                { title: 'A Complete Guide to Flexbox', source: 'CSS-Tricks', url: 'https://css-tricks.com/snippets/css/a-guide-to-flexbox/', readTime: '20 min' },
            ],
            courses: [
                { title: 'Meta Front-End Developer Professional Certificate', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/meta-front-end-developer', rating: 4.8 },
                { title: 'Full Stack Open 2024', platform: 'University of Helsinki', url: 'https://fullstackopen.com/en/', rating: 4.9 },
            ],
            tools: [
                { name: 'VS Code', type: 'Editor', url: 'https://code.visualstudio.com/' },
                { name: 'Figma', type: 'Design', url: 'https://www.figma.com/' },
                { name: 'Tailwind CSS', type: 'Framework', url: 'https://tailwindcss.com/' },
            ]
        },
        'Backend Developer': {
            videos: [
                { title: 'Node.js Backend Architecture', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=nodejs+backend+architecture', duration: '8h' },
                { title: 'Software Architecture: The Hard Parts', platform: 'O\'Reilly', url: 'https://www.oreilly.com/library/view/software-architecture-the/9781492086888/', duration: 'Book/Video' },
                { title: 'Designing Data-Intensive Applications', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=designing+data+intensive+applications+martin+kleppmann', duration: '5h' },
            ],
            articles: [
                { title: 'Microservices Guide', source: 'Martin Fowler', url: 'https://martinfowler.com/articles/microservices.html', readTime: '25 min' },
                { title: 'REST API Best Practices', source: 'Microsoft', url: 'https://learn.microsoft.com/en-us/azure/architecture/best-practices/api-design', readTime: '15 min' },
                { title: 'PostgreSQL Performance Optimization', source: 'Medium', url: 'https://medium.com/tag/postgresql', readTime: '12 min' },
            ],
            courses: [
                { title: 'Node.js Developer Course', platform: 'Udemy', url: 'https://www.udemy.com/course/the-complete-nodejs-developer-course-2/', rating: 4.7 },
                { title: 'Architecting on AWS', platform: 'Coursera', url: 'https://www.coursera.org/specializations/aws-fundamentals', rating: 4.8 },
            ],
            tools: [
                { name: 'Postman', type: 'API Testing', url: 'https://www.postman.com/' },
                { name: 'Docker', type: 'Containerization', url: 'https://www.docker.com/' },
                { name: 'Prisma', type: 'ORM', url: 'https://www.prisma.io/' },
            ]
        },
        'AI / ML Engineer': {
            videos: [
                { title: 'Linear Algebra for ML', platform: 'YouTube', url: 'https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab', duration: '3h' },
                { title: 'PyTorch for Deep Learning', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=pytorch+for+deep+learning+full+course', duration: '10h' },
                { title: 'Generative AI and Transformers', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=karpathy+transformers+course', duration: '2h' },
            ],
            articles: [
                { title: 'Attention Is All You Need', source: 'ArXiv', url: 'https://arxiv.org/abs/1706.03762', readTime: '30 min' },
                { title: 'Introduction to Machine Learning', source: 'Google', url: 'https://developers.google.com/machine-learning/crash-course', readTime: 'Self-paced' },
                { title: 'Towards Data Science Blog', source: 'Medium', url: 'https://towardsdatascience.com/', readTime: 'Daily' },
            ],
            courses: [
                { title: 'Machine Learning Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/machine-learning-introduction', rating: 4.9 },
                { title: 'Deep Learning Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/deep-learning', rating: 4.9 },
            ],
            tools: [
                { name: 'Jupyter Labs', type: 'IDE', url: 'https://jupyter.org/' },
                { name: 'Scikit-Learn', type: 'ML Library', url: 'https://scikit-learn.org/' },
                { name: 'PyTorch', type: 'Framework', url: 'https://pytorch.org/' },
            ]
        },
        'Cyber Security': {
            videos: [
                { title: 'CompTIA Security+ Full Course', platform: 'YouTube', url: 'https://www.youtube.com/playlist?list=PLG49S3nxzAnl4QDVqK-hOnoqkSKEIDDG2', duration: '15h' },
                { title: 'Ethical Hacking Full Course', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=ethical+hacking+full+course', duration: '20h' },
            ],
            articles: [
                { title: 'OWASP Top 10 Guides', source: 'OWASP', url: 'https://owasp.org/www-project-top-ten/', readTime: '45 min' },
                { title: 'Cybersecurity for Beginners', source: 'IBM', url: 'https://www.ibm.com/topics/cybersecurity', readTime: '15 min' },
            ],
            courses: [
                { title: 'Google Cybersecurity Certificate', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/google-cybersecurity', rating: 4.8 },
                { title: 'Certified Ethical Hacker (CEH)', platform: 'EC-Council', url: 'https://www.eccouncil.org/programs/certified-ethical-hacker-ceh/', rating: 4.9 },
            ],
            tools: [
                { name: 'Kali Linux', type: 'OS', url: 'https://www.kali.org/' },
                { name: 'Nmap', type: 'Scanner', url: 'https://nmap.org/' },
                { name: 'Burp Suite', type: 'Web Security', url: 'https://portswigger.net/burp' },
            ]
        },
        'UI/UX Designer': {
            videos: [
                { title: 'Design Principles & Theory', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=design+principles+ux', duration: '4h' },
                { title: 'Figma Mastery 2024', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=figma+full+tutorial', duration: '6h' },
            ],
            articles: [
                { title: 'Don\'t Make Me Think (Guide)', source: 'UX Collective', url: 'https://uxdesign.cc/', readTime: 'Self-paced' },
                { title: 'Laws of UX', source: 'LawsOfUX.com', url: 'https://lawsofux.com/', readTime: '20 min' },
            ],
            courses: [
                { title: 'Google UX Design Certificate', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/google-ux-design', rating: 4.8 },
                { title: 'UX Certification', platform: 'Nielsen Norman Group', url: 'https://www.nngroup.com/training/', rating: 4.9 },
            ],
            tools: [
                { name: 'Figma', type: 'Primary Design', url: 'https://www.figma.com/' },
                { name: 'Miro', type: 'Brainstorming', url: 'https://miro.com/' },
                { name: 'Notion', type: 'Documentation', url: 'https://www.notion.so/' },
            ]
        },
        'QA / Automation Engineer': {
            videos: [
                { title: 'Selenium WebDriver Full Course', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=selenium+webdriver+course', duration: '12h' },
                { title: 'Playwright Mastery 2024', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=playwright+full+tutorial', duration: '8h' },
            ],
            articles: [
                { title: 'The Test Automation Pyramid', source: 'Martin Fowler', url: 'https://martinfowler.com/articles/practical-test-pyramid.html', readTime: '20 min' },
                { title: 'Agile Testing Framework', source: 'Agile Alliance', url: 'https://www.agilealliance.org/glossary/agile-testing/', readTime: '15 min' },
            ],
            courses: [
                { title: 'Certified Software Automation Specialist', platform: 'Simplilearn', url: 'https://www.simplilearn.com/automation-testing-masters-program-certification-training-course', rating: 4.7 },
                { title: 'API Testing Mastery', platform: 'Postman', url: 'https://www.postman.com/testing/', rating: 4.8 },
            ],
            tools: [
                { name: 'Selenium', type: 'Web Automation', url: 'https://www.selenium.dev/' },
                { name: 'Playwright', type: 'Modern UI Auth', url: 'https://playwright.dev/' },
                { name: 'Postman', type: 'API Testing', url: 'https://www.postman.com/' },
            ]
        },
        'Full-Stack Developer': {
            videos: [
                { title: 'Full Stack Web Development Bootcamp', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=full+stack+web+development+course', duration: '40h' },
                { title: 'The Modern FullStack Architecture', platform: 'Design Guru', url: 'https://www.designgurus.io/course/grokking-the-system-design-interview', duration: '15h' },
            ],
            articles: [
                { title: 'Architecting Scalable Apps', source: 'DigitalOcean', url: 'https://www.digitalocean.com/community/tutorials/architecting-applications-for-production', readTime: '30 min' },
                { title: 'Next.js 14 Complete Guide', source: 'Next.js Docs', url: 'https://nextjs.org/docs', readTime: 'Self-paced' },
            ],
            courses: [
                { title: 'Full Stack Open', platform: 'University of Helsinki', url: 'https://fullstackopen.com/en/', rating: 4.9 },
                { title: 'The Complete Web Developer', platform: 'Udemy', url: 'https://www.udemy.com/course/the-complete-web-developer-zero-to-mastery/', rating: 4.8 },
            ],
            tools: [
                { name: 'GitKraken', type: 'Git Client', url: 'https://www.gitkraken.com/' },
                { name: 'Vercel', type: 'Deployment', url: 'https://vercel.com/' },
                { name: 'Supabase', type: 'Backend-as-a-Service', url: 'https://supabase.com/' },
            ]
        },
        'DevOps Engineer': {
            videos: [
                { title: 'CI/CD Pipeline Mastery', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=devops+cicd+pipeline+tutorial', duration: '6h' },
                { title: 'Kubernetes for Absolute Beginners', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=kubernetes+tutorial+for+beginners', duration: '5h' },
            ],
            articles: [
                { title: 'Infrastructure as Code (IaC) Guide', source: 'HashiCorp', url: 'https://developer.hashicorp.com/terraform/intro', readTime: '20 min' },
                { title: 'The Site Reliability Hierarchy', source: 'Google SRE', url: 'https://sre.google/sre-book/introduction/', readTime: '45 min' },
            ],
            courses: [
                { title: 'DevOps on AWS Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/aws-devops', rating: 4.8 },
                { title: 'Docker Certified Associate', platform: 'Docker', url: 'https://training.mirantis.com/certification/dca-certification-exam/', rating: 4.7 },
            ],
            tools: [
                { name: 'Terraform', type: 'IaC', url: 'https://www.terraform.io/' },
                { name: 'Jenkins', type: 'Automation', url: 'https://www.jenkins.io/' },
                { name: 'Prometheus', type: 'Monitoring', url: 'https://prometheus.io/' },
            ]
        },
        'Data Scientist': {
            videos: [
                { title: 'Data Science Full Course', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=data+science+full+course', duration: '12h' },
                { title: 'Statistical Thinking in Python', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=statistics+for+data+science', duration: '6h' },
            ],
            articles: [
                { title: 'Probability & Statistics Guide', source: 'TowardsDS', url: 'https://towardsdatascience.com/probability-and-statistics/', readTime: '25 min' },
                { title: 'The Data Science Lifecycle', source: 'Microsoft', url: 'https://learn.microsoft.com/en-us/azure/architecture/data-guide/data-science-lifecycle', readTime: '20 min' },
            ],
            courses: [
                { title: 'IBM Data Science Professional', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/ibm-data-science', rating: 4.8 },
                { title: 'Advanced Data Science', platform: 'Harvard', url: 'https://pll.harvard.edu/subject/data-science', rating: 4.9 },
            ],
            tools: [
                { name: 'Anaconda', type: 'Environment', url: 'https://www.anaconda.com/' },
                { name: 'Tableau', type: 'Visualization', url: 'https://www.tableau.com/' },
                { name: 'Pandas', type: 'Data Library', url: 'https://pandas.pydata.org/' },
            ]
        },
        'Cloud Engineer': {
            videos: [
                { title: 'Cloud Computing Architecture', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=cloud+computing+full+course', duration: '10h' },
                { title: 'AWS vs Azure vs GCP', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=aws+vs+azure+vs+gcp+comparison', duration: '2h' },
            ],
            articles: [
                { title: 'Choosing the Right Cloud Strategy', source: 'Gartner', url: 'https://www.gartner.com/en/information-technology/glossary/cloud-computing', readTime: '15 min' },
                { title: 'Serverless Architecture Guide', source: 'AWS', url: 'https://aws.amazon.com/serverless/', readTime: '20 min' },
            ],
            courses: [
                { title: 'AWS Cloud Practitioner', platform: 'Coursera', url: 'https://www.coursera.org/learn/aws-cloud-practitioner-essentials', rating: 4.8 },
                { title: 'Azure Administrator Associate', platform: 'Microsoft', url: 'https://learn.microsoft.com/en-us/credentials/certifications/azure-administrator/', rating: 4.7 },
            ],
            tools: [
                { name: 'AWS Management Console', type: 'Cloud', url: 'https://aws.amazon.com/' },
                { name: 'Google Cloud Shell', type: 'CLI', url: 'https://cloud.google.com/shell' },
                { name: 'Azure Portal', type: 'Cloud', url: 'https://portal.azure.com/' },
            ]
        },
        'Mobile App Developer': {
            videos: [
                { title: 'Flutter App Development', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=flutter+full+course', duration: '15h' },
                { title: 'SwiftUI Mastery for iOS', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=swiftui+full+course', duration: '12h' },
            ],
            articles: [
                { title: 'Mobile App Architecture Patterns', source: 'Medium', url: 'https://medium.com/tag/mobile-app-development', readTime: '20 min' },
                { title: 'Apple Human Interface Guidelines', source: 'Apple', url: 'https://developer.apple.com/design/human-interface-guidelines/', readTime: 'Self-paced' },
            ],
            courses: [
                { title: 'IOS & Swift Bootcamp', platform: 'Udemy', url: 'https://www.udemy.com/course/ios-13-app-development-bootcamp/', rating: 4.8 },
                { title: 'Android Kotlin Developer', platform: 'Google', url: 'https://developer.android.com/courses/android-basics-kotlin/course', rating: 4.9 },
            ],
            tools: [
                { name: 'Xcode', type: 'iOS IDE', url: 'https://developer.apple.com/xcode/' },
                { name: 'Android Studio', type: 'Android IDE', url: 'https://developer.android.com/studio' },
                { name: 'Expo', type: 'React Native', url: 'https://expo.dev/' },
            ]
        },
        'Business Analyst': {
            videos: [
                { title: 'Business Analyst Fundamentals', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=business+analyst+fundamentals', duration: '5h' },
                { title: 'Data Visualization for Analysts', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=data+visualization+for+business+analysts', duration: '4h' },
            ],
            articles: [
                { title: 'The IIBA Guide to Business Analysis', source: 'IIBA', url: 'https://www.iiba.org/learning-development/knowledge-centre/', readTime: 'Self-paced' },
                { title: 'Requirements Gathering Techniques', source: 'MindTools', url: 'https://www.mindtools.com/pages/article/newTMC_80.htm', readTime: '15 min' },
            ],
            courses: [
                { title: 'Google Data Analytics Professional Certificate', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/google-data-analytics', rating: 4.8 },
                { title: 'Business Analysis Foundations', platform: 'LinkedIn Learning', url: 'https://www.linkedin.com/learning/business-analysis-foundations-2', rating: 4.7 },
            ],
            tools: [
                { name: 'Microsoft Excel', type: 'Data Analysis', url: 'https://www.microsoft.com/en-us/microsoft-365/excel' },
                { name: 'Tableau', type: 'Visualization', url: 'https://www.tableau.com/' },
                { name: 'Jira', type: 'Requirement Tracking', url: 'https://www.atlassian.com/software/jira' },
            ]
        },
        'Product Manager': {
            videos: [
                { title: 'Product Management for Beginners', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=product+management+introduction', duration: '6h' },
                { title: 'Agile Product Ownership', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=agile+product+ownership+in+a+nutshell', duration: '1h' },
            ],
            articles: [
                { title: 'The Product Manager\'s Playbook', source: 'Product School', url: 'https://productschool.com/blog/', readTime: 'Self-paced' },
                { title: 'How to Write a PRD', source: 'Atlassian', url: 'https://www.atlassian.com/agile/product-management/product-requirements-document', readTime: '20 min' },
            ],
            courses: [
                { title: 'Digital Product Management Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/digital-product-management', rating: 4.8 },
                { title: 'Product Management Program', platform: 'Reforge', url: 'https://www.reforge.com/', rating: 4.9 },
            ],
            tools: [
                { name: 'Notion', type: 'Roadmapping', url: 'https://www.notion.so/' },
                { name: 'Productboard', type: 'Product Strategy', url: 'https://www.productboard.com/' },
                { name: 'Mixpanel', type: 'User Analytics', url: 'https://mixpanel.com/' },
            ]
        },
        'Graphic Designer': {
            videos: [
                { title: 'Graphic Design Theory', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=graphic+design+theory+full+course', duration: '4h' },
                { title: 'Adobe Illustrator Full Course', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=adobe+illustrator+full+course', duration: '10h' },
            ],
            articles: [
                { title: 'Principles of Design', source: 'Adobe', url: 'https://www.adobe.com/creativecloud/design/discover/principles-of-design.html', readTime: '15 min' },
                { title: 'Color Theory for Designers', source: 'Smashing Magazine', url: 'https://www.smashingmagazine.com/2010/01/color-theory-for-designers-part-1-the-meaning-of-color/', readTime: '20 min' },
            ],
            courses: [
                { title: 'Graphic Design Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/graphic-design', rating: 4.8 },
                { title: 'Layout for Graphic Designers', platform: 'LinkedIn Learning', url: 'https://www.linkedin.com/learning/layout-and-composition-for-graphic-designers', rating: 4.7 },
            ],
            tools: [
                { name: 'Adobe Photoshop', type: 'Raster Design', url: 'https://www.adobe.com/products/photoshop.html' },
                { name: 'Canva', type: 'Quick Design', url: 'https://www.canva.com/' },
                { name: 'Pinterest', type: 'Inspiration', url: 'https://www.pinterest.com/' },
            ]
        },
        'Video Editor': {
            videos: [
                { title: 'Video Editing Basics', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=video+editing+for+beginners', duration: '3h' },
                { title: 'Premiere Pro Mastery', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=adobe+premiere+pro+full+course', duration: '12h' },
            ],
            articles: [
                { title: 'The Art of Video Editing', source: 'Adobe', url: 'https://www.adobe.com/creativecloud/video/discover/video-editing-basics.html', readTime: '20 min' },
                { title: 'Color Grading 101', source: 'Cinecom', url: 'https://www.cinecom.net/', readTime: '15 min' },
            ],
            courses: [
                { title: 'Professional Video Editing', platform: 'Udemy', url: 'https://www.udemy.com/course/adobe-premiere-pro-video-editing/', rating: 4.8 },
                { title: 'Video Production Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/video-production', rating: 4.7 },
            ],
            tools: [
                { name: 'DaVinci Resolve', type: 'Grading/Editing', url: 'https://www.blackmagicdesign.com/products/davinciresolve' },
                { name: 'Premiere Pro', type: 'Editor', url: 'https://www.adobe.com/products/premiere.html' },
                { name: 'Epidemic Sound', type: 'Assets', url: 'https://www.epidemicsound.com/' },
            ]
        }
    };

    const getFieldResources = () => {
        return resourcesDatabase[userData.field] || {
            videos: [
                { title: 'Foundational Principles of ' + userData.field, platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=' + userData.field + '+fundamentals', duration: '5h' },
                { title: 'Strategic Industry Overview', platform: 'YouTube', url: 'https://www.youtube.com/results?search_query=' + userData.field + '+career+path', duration: '2h' },
            ],
            articles: [
                { title: 'The Complete Guide to ' + userData.field, source: 'Industry Intelligence', url: 'https://www.google.com/search?q=' + userData.field + '+guide', readTime: '25 min' },
                { title: 'Market Trends & Analytics', source: 'Strategic Research', url: 'https://www.google.com/search?q=' + userData.field + '+trends+2024', readTime: '15 min' },
            ],
            courses: [
                { title: userData.field + ' Masterclass', platform: 'Udemy', url: 'https://www.udemy.com/courses/search/?q=' + userData.field, rating: 4.7 },
                { title: 'Professional Certification in ' + userData.field, platform: 'Coursera', url: 'https://www.coursera.org/search?query=' + userData.field, rating: 4.8 },
            ],
            tools: [
                { name: 'Industry Standard Toolset', type: 'Productivity', url: '#' },
                { name: 'Technical Workspace', type: 'Infrastructure', url: '#' },
                { name: 'Collaborative Environment', type: 'Communication', url: '#' },
            ]
        };
    };

    const recommendedResources = getFieldResources();

    const categories = [
        { id: 'all', label: 'All Resources', icon: '📚' },
        { id: 'videos', label: 'Videos', icon: '🎥' },
        { id: 'articles', label: 'Articles', icon: '📖' },
        { id: 'courses', label: 'Courses', icon: '🎓' },
        { id: 'tools', label: 'Tools', icon: '🛠️' },
    ];

    return (
        <div className="resources animate-fade-in">
            {/* Header */}
            <div className="resources-header">
                <h2>📚 TECHNICAL VAULT</h2>
                <p className="resources-desc">
                    Professional curated materials for your {userData.field} trajectory.
                </p>
            </div>

            {/* Category Filter */}
            <div className="category-filter">
                {categories.map(cat => (
                    <button
                        key={cat.id}
                        className={`category-btn ${activeCategory === cat.id ? 'active' : ''}`}
                        onClick={() => setActiveCategory(cat.id)}
                    >
                        {cat.label}
                    </button>
                ))}
            </div>

            {/* Recommended Resources */}
            <div className="resources-content">
                {(activeCategory === 'all' || activeCategory === 'videos') && (
                    <section className="resources-section">
                        <h2>🎥 VIDEO SYLLABUS</h2>
                        <div className="resources-grid">
                            {recommendedResources.videos.map((video, index) => (
                                <div key={index} className="resource-card">
                                    <div className="resource-icon">🎥</div>
                                    <h4 className="resource-title">{video.title}</h4>
                                    <div className="resource-meta">
                                        <span className="badge">{video.platform}</span>
                                        <span className="resource-duration">{video.duration}</span>
                                    </div>
                                    <a href={video.url} target="_blank" rel="noopener noreferrer" className="btn-resource">Initialize</a>
                                </div>
                            ))}
                        </div>
                    </section>
                )}

                {(activeCategory === 'all' || activeCategory === 'articles') && (
                    <section className="resources-section">
                        <h2>📖 TECHNICAL DOCUMENTATION</h2>
                        <div className="resources-grid">
                            {recommendedResources.articles.map((article, index) => (
                                <div key={index} className="resource-card">
                                    <div className="resource-icon">📖</div>
                                    <h4 className="resource-title">{article.title}</h4>
                                    <div className="resource-meta">
                                        <span className="badge">{article.source}</span>
                                        <span className="resource-duration">{article.readTime}</span>
                                    </div>
                                    <a href={article.url} target="_blank" rel="noopener noreferrer" className="btn-resource">Read</a>
                                </div>
                            ))}
                        </div>
                    </section>
                )}

                {(activeCategory === 'all' || activeCategory === 'courses') && (
                    <section className="resources-section">
                        <h2>🎓 PROFESSIONAL COURSES</h2>
                        <div className="resources-grid">
                            {recommendedResources.courses.map((course, index) => (
                                <div key={index} className="resource-card">
                                    <div className="resource-icon">🎓</div>
                                    <h4 className="resource-title">{course.title}</h4>
                                    <div className="resource-meta">
                                        <span className="badge">{course.platform}</span>
                                        <span className="resource-duration">★ {course.rating}</span>
                                    </div>
                                    <a href={course.url} target="_blank" rel="noopener noreferrer" className="btn-resource">Enroll</a>
                                </div>
                            ))}
                        </div>
                    </section>
                )}

                {(activeCategory === 'all' || activeCategory === 'tools') && (
                    <section className="resources-section">
                        <h2>🛠️ UTILITY STACK</h2>
                        <div className="tools-grid">
                            {recommendedResources.tools.map((tool, index) => (
                                <div key={index} className="tool-card">
                                    <div className="tool-icon">✧</div>
                                    <div className="tool-details">
                                        <div className="tool-name">{tool.name}</div>
                                        <div className="tool-type">{tool.type}</div>
                                    </div>
                                    <a href={tool.url} target="_blank" rel="noopener noreferrer" className="btn-resource">Open</a>
                                </div>
                            ))}
                        </div>
                    </section>
                )}
            </div>

        </div>
    );
};

export default Resources;
