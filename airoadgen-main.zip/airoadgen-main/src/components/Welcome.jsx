import { useState, useEffect } from 'react';
import './Welcome.css';

const Welcome = ({ onGetStarted }) => {
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        setIsVisible(true);
    }, []);

    return (
        <div className={`welcome ${isVisible ? 'visible' : ''}`}>
            <div className="container">
                <div className="welcome-content">
                    {/* Logo/Icon */}
                    <div className="welcome-icon">
                        <div className="icon-circle">
                            ✧
                        </div>
                    </div>

                    {/* Main Heading */}
                    <h1 className="welcome-title">
                        ARCHITECT YOUR
                        <br />
                        <span className="text-gradient">FUTURE</span>
                    </h1>

                    {/* Subtitle */}
                    <p className="welcome-subtitle">
                        A strictly professional AI-driven system for career roadmap orchestration.
                    </p>

                    {/* Features */}
                    <div className="welcome-features">
                        <div className="feature-item">
                            <div className="feature-icon">🎯</div>
                            <div className="feature-text">Precision Paths</div>
                        </div>
                        <div className="feature-item">
                            <div className="feature-icon">📅</div>
                            <div className="feature-text">Strategic Tasks</div>
                        </div>
                        <div className="feature-item">
                            <div className="feature-icon">📊</div>
                            <div className="feature-text">Advanced Analytics</div>
                        </div>
                    </div>

                    {/* CTA Button */}
                    <button
                        className="btn-proper"
                        onClick={onGetStarted}
                    >
                        <span>Initialize System</span>
                        <svg
                            className="btn-icon-svg"
                            width="20"
                            height="20"
                            viewBox="0 0 20 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M4 10H16M16 10L10 4M16 10L10 16"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                        </svg>
                    </button>

                    {/* Stats */}
                    <div className="welcome-stats">
                        <div className="stat-item">
                            <div className="stat-number">50+</div>
                            <div className="stat-label">Sectors</div>
                        </div>
                        <div className="stat-divider"></div>
                        <div className="stat-item">
                            <div className="stat-number">100%</div>
                            <div className="stat-label">Static Build</div>
                        </div>
                        <div className="stat-divider"></div>
                        <div className="stat-item">
                            <div className="stat-number">AI</div>
                            <div className="stat-label">Engine</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Welcome;
