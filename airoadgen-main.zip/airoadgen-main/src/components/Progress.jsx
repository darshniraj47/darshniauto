import './Progress.css';

const Progress = ({ progressData }) => {
    const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    const getBadges = () => {
        const badges = [];
        if (progressData.streak >= 3) badges.push({ icon: '✧', name: 'CONSISTENCY PROTOCOL', desc: '3-Day operational streak achieved.' });
        if (progressData.streak >= 7) badges.push({ icon: '✧', name: 'WARRIOR STATUS', desc: '7-Day technical mastery maintained.' });
        if (progressData.streak >= 30) badges.push({ icon: '✧', name: 'ELITE ARCHITECT', desc: '30-Day strategic dedication.' });
        if (progressData.tasksCompleted >= 10) badges.push({ icon: '✧', name: 'TASK EXECUTION', desc: '10+ critical objectives secured.' });
        if (progressData.xp >= 100) badges.push({ icon: '✧', name: 'XP THRESHOLD', desc: '100+ technical experience points.' });
        if (progressData.level >= 5) badges.push({ icon: '✧', name: 'RANK V', desc: 'Senior level accreditation granted.' });
        return badges;
    };

    const badges = getBadges();

    return (
        <div className="progress-view animate-fade-in">
            {/* System Status - Top Grid */}
            <div className="system-status-grid">
                <div className="status-main-card">
                    <div className="status-header">
                        <span className="node-id">NODE_01</span>
                        <h3>SYSTEM COMPLETION</h3>
                    </div>

                    <div className="precision-gauge">
                        <div className="gauge-track">
                            <div
                                className="gauge-fill"
                                style={{ width: `${progressData.completionPercentage}%` }}
                            ></div>
                        </div>
                        <div className="gauge-metrics">
                            <span className="gauge-value">{progressData.completionPercentage}%</span>
                            <span className="gauge-label">INTEGRATION SCALE</span>
                        </div>
                    </div>

                    <p className="status-log">
                        Trajectory analyzed. Current progress correlates with established benchmarks.
                    </p>
                </div>

                <div className="stats-matrix">
                    <div className="matrix-row">
                        <span className="matrix-label">OPERATIONAL STREAK</span>
                        <span className="matrix-value">{progressData.streak} DAYS</span>
                    </div>
                    <div className="matrix-row">
                        <span className="matrix-label">OBJECTIVES SECURED</span>
                        <span className="matrix-value">{progressData.tasksCompleted} UNITS</span>
                    </div>
                    <div className="matrix-row">
                        <span className="matrix-label">EXPERIENCE POINTS</span>
                        <span className="matrix-value">{progressData.xp} XP</span>
                    </div>
                    <div className="matrix-row highlight">
                        <span className="matrix-label">CURRENT RANK</span>
                        <span className="matrix-value">LEVEL {progressData.level}</span>
                    </div>
                </div>
            </div>

            {/* Performance Analytics */}
            <section className="progress-section">
                <div className="section-header-tech">
                    <span className="tech-line"></span>
                    <h2>WEEKLY PERFORMANCE ANALYTICS</h2>
                    <span className="tech-line"></span>
                </div>

                <div className="chart-technical-container">
                    <div className="technical-bars">
                        {daysOfWeek.map((day, index) => {
                            const value = progressData.weeklyProgress[index] || 0;
                            const maxValue = Math.max(...progressData.weeklyProgress, 1);
                            const heightPercent = (value / maxValue) * 100;

                            return (
                                <div key={day} className="tech-bar-col">
                                    <div className="tech-bar-track">
                                        <div
                                            className="tech-bar-fill"
                                            style={{ height: `${heightPercent}%` }}
                                        >
                                            <span className="tech-bar-val">{value}</span>
                                        </div>
                                    </div>
                                    <div className="tech-bar-label">{day.toUpperCase()}</div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </section>

            {/* Achievement Matrix */}
            <section className="progress-section">
                <div className="section-header-tech">
                    <span className="tech-line"></span>
                    <h2>ACHIEVEMENT PROTOCOLS</h2>
                    <span className="tech-line"></span>
                </div>

                {badges.length > 0 ? (
                    <div className="achievement-matrix-grid">
                        {badges.map((badge, index) => (
                            <div key={index} className="achievement-box">
                                <div className="achievement-top">
                                    <span className="achievement-icon">{badge.icon}</span>
                                    <span className="achievement-code">ACQ_{index + 100}</span>
                                </div>
                                <div className="achievement-name">{badge.name}</div>
                                <div className="achievement-desc">{badge.desc}</div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="null-state">
                        <p>PROTOCOL DATA SHIFTING. EXECUTE TASKS TO POPULATE ACHIEVEMENTS.</p>
                    </div>
                )}
            </section>

            {/* Rank Evolution */}
            <section className="progress-section">
                <div className="section-header-tech">
                    <span className="tech-line"></span>
                    <h2>RANK EVOLUTION</h2>
                    <span className="tech-line"></span>
                </div>

                <div className="rank-evolution-strip">
                    <div className="rank-node">
                        <span className="rank-sub">CURRENT</span>
                        <div className="rank-hex">{progressData.level}</div>
                    </div>

                    <div className="rank-progress-detail">
                        <div className="rank-track-technical">
                            <div
                                className="rank-fill-technical"
                                style={{ width: `${(progressData.xp % 100)}%` }}
                            ></div>
                        </div>
                        <div className="rank-xp-matrix">
                            <span>SYNC_COMPLETE: {progressData.xp % 100}%</span>
                            <span>{100 - (progressData.xp % 100)} XP UNTIL NEXT EVOLUTION</span>
                        </div>
                    </div>

                    <div className="rank-node next">
                        <span className="rank-sub">REQUISITE</span>
                        <div className="rank-hex secondary">{progressData.level + 1}</div>
                    </div>
                </div>
            </section>

            {/* System Insight */}
            <div className="insight-terminal">
                <div className="terminal-header">
                    <div className="terminal-controls">
                        <span className="terminal-dot"></span>
                        <span className="terminal-dot"></span>
                        <span className="terminal-dot"></span>
                    </div>
                    <span className="terminal-title">SYSTEM_INSIGHT.LOG</span>
                </div>
                <div className="terminal-body">
                    <div className="terminal-lines">
                        <div className="log-line">
                            <span className="log-timestamp">[{new Date().toISOString().split('T')[1].split('.')[0]}]</span>
                            <span className="log-level info">INFO</span>
                            <span className="log-content">System diagnostics initialized...</span>
                        </div>
                        <div className="log-line">
                            <span className="log-timestamp">[{new Date().toISOString().split('T')[1].split('.')[0]}]</span>
                            <span className="log-level success">OK</span>
                            <span className="log-content">Analyzing operational trajectory: {progressData.completionPercentage}% complete.</span>
                        </div>
                        {progressData.streak >= 3 && (
                            <div className="log-line">
                                <span className="log-timestamp">[{new Date().toISOString().split('T')[1].split('.')[0]}]</span>
                                <span className="log-level warning">STREAK</span>
                                <span className="log-content">Consistency protocol active. {progressData.streak} day streak maintained.</span>
                            </div>
                        )}
                        {progressData.xp % 100 > 80 && (
                            <div className="log-line">
                                <span className="log-timestamp">[{new Date().toISOString().split('T')[1].split('.')[0]}]</span>
                                <span className="log-level info">SYNC</span>
                                <span className="log-content">Evolution near. XP threshold approaching next rank capacity.</span>
                            </div>
                        )}
                        <div className="log-line current">
                            <span className="terminal-prompt">{'>'}</span>
                            <span className="terminal-text">
                                {progressData.completionPercentage < 20
                                    ? "Initial deployment phase. Focus on fundamental objective acquisition."
                                    : progressData.completionPercentage < 50
                                        ? "Integration phase. Accelerating technical consolidation protocols."
                                        : "Advanced optimization. Refining architectural mastery and execution speed."}
                            </span>
                            <span className="terminal-cursor"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Progress;
