import { useState, useEffect } from 'react';
import './DailyTasks.css';

const DailyTasks = ({ roadmapData, progressData, setProgressData }) => {
    const [selectedDay, setSelectedDay] = useState(0);
    // Use local state for tasks to trigger re-renders
    const [dailyTasks, setDailyTasks] = useState(roadmapData.dailyTasks);

    const todaysTasks = dailyTasks[selectedDay] || dailyTasks[0];

    // Sync local state with roadmapData when it changes
    useEffect(() => {
        setDailyTasks(roadmapData.dailyTasks);
    }, [roadmapData.dailyTasks]);

    const handleMarkAllComplete = () => {
        const updatedTasks = dailyTasks.map((day, dayIndex) => {
            if (dayIndex === selectedDay) {
                const updatedDayTasks = day.tasks.map(task => ({ ...task, completed: true }));
                return { ...day, tasks: updatedDayTasks, completed: true };
            }
            return day;
        });

        // Calculate XP for all incomplete tasks that get completed
        const incompleteTasks = todaysTasks.tasks.filter(t => !t.completed);
        const xpGained = incompleteTasks.reduce((sum, task) => sum + task.duration, 0);

        if (incompleteTasks.length > 0) {
            setProgressData(prev => ({
                ...prev,
                tasksCompleted: prev.tasksCompleted + incompleteTasks.length,
                xp: prev.xp + xpGained,
                streak: prev.streak + 1,
                completionPercentage: Math.min(prev.completionPercentage + 2, 100),
                level: Math.floor((prev.xp + xpGained) / 100) + 1,
            }));
        }

        // Update local state to trigger re-render
        setDailyTasks(updatedTasks);
        // Also update the roadmapData reference for persistence
        roadmapData.dailyTasks = updatedTasks;
    };

    const handleRescheduleTasks = () => {
        // Reset all tasks to incomplete for the selected day
        const updatedTasks = dailyTasks.map((day, dayIndex) => {
            if (dayIndex === selectedDay) {
                const updatedDayTasks = day.tasks.map(task => ({ ...task, completed: false }));
                return { ...day, tasks: updatedDayTasks, completed: false };
            }
            return day;
        });

        // Update local state to trigger re-render
        setDailyTasks(updatedTasks);
        // Also update the roadmapData reference for persistence
        roadmapData.dailyTasks = updatedTasks;
    };

    const handleTaskToggle = (taskId) => {
        // Update task completion
        const updatedTasks = dailyTasks.map((day, dayIndex) => {
            if (dayIndex === selectedDay) {
                const updatedDayTasks = day.tasks.map(task =>
                    task.id === taskId ? { ...task, completed: !task.completed } : task
                );
                return { ...day, tasks: updatedDayTasks };
            }
            return day;
        });

        // Calculate new progress
        const completedTasks = updatedTasks[selectedDay].tasks.filter(t => t.completed).length;
        const totalTasks = updatedTasks[selectedDay].tasks.length;
        const allCompleted = completedTasks === totalTasks;
        const wasAllCompleted = todaysTasks.tasks.filter(t => t.completed).length === totalTasks;

        // Update progress data only when all tasks are completed for the first time
        if (allCompleted && !wasAllCompleted) {
            setProgressData(prev => ({
                ...prev,
                tasksCompleted: prev.tasksCompleted + totalTasks,
                xp: prev.xp + (totalTasks * 10),
                streak: prev.streak + 1,
                completionPercentage: Math.min(prev.completionPercentage + 2, 100),
                level: Math.floor((prev.xp + (totalTasks * 10)) / 100) + 1,
            }));
        }

        // Update local state to trigger re-render
        setDailyTasks(updatedTasks);
        // Also update the roadmapData reference for persistence
        roadmapData.dailyTasks = updatedTasks;
    };

    const getTaskIcon = (type) => {
        switch (type) {
            case 'reading':
                return '📖';
            case 'practice':
                return '💻';
            case 'project':
                return '🚀';
            case 'revision':
                return '🔄';
            default:
                return '📝';
        }
    };

    const getCompletionStatus = () => {
        const completed = todaysTasks.tasks.filter(t => t.completed).length;
        const total = todaysTasks.tasks.length;
        return { completed, total, percentage: (completed / total) * 100 };
    };

    const status = getCompletionStatus();

    return (
        <div className="daily-tasks animate-fade-in">
            {/* Header */}
            <div className="tasks-header">
                <h2>📅 Daily Tasks</h2>
                <div className="tasks-meta">
                    <div className="date-badge badge badge-primary">{todaysTasks.date}</div>
                    <div className="completion-badge badge badge-success">
                        {status.completed}/{status.total} Complete
                    </div>
                </div>
            </div>

            {/* Day Selector */}
            <div className="day-selector">
                {dailyTasks.map((day, index) => (
                    <button
                        key={day.day}
                        className={`day-btn ${selectedDay === index ? 'active' : ''} ${day.completed ? 'completed' : ''
                            }`}
                        onClick={() => setSelectedDay(index)}
                    >
                        <div className="day-number">Day {day.day}</div>
                        <div className="day-status">
                            {day.completed ? '✓' : day.day === 1 ? 'Today' : ''}
                        </div>
                    </button>
                ))}
            </div>

            {/* Progress Bar */}
            <div className="task-progress-bar">
                <div className="progress-track">
                    <div
                        className="progress-fill"
                        style={{ width: `${status.percentage}%` }}
                    ></div>
                </div>
                <div className="progress-label">{Math.round(status.percentage)}% Complete</div>
            </div>

            {/* Task List */}
            <div className="task-list">
                {todaysTasks.tasks.map((task) => (
                    <div
                        key={task.id}
                        className={`task-item ${task.completed ? 'completed' : ''}`}
                        onClick={() => handleTaskToggle(task.id)}
                    >
                        <div className="task-checkbox">
                            <div className={`checkbox ${task.completed ? 'checked' : ''}`}>
                                {task.completed && (
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path
                                            d="M3 8L6.5 11.5L13 4.5"
                                            stroke="currentColor"
                                            strokeWidth="2"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        />
                                    </svg>
                                )}
                            </div>
                        </div>

                        <div className="task-icon">{getTaskIcon(task.type)}</div>

                        <div className="task-details">
                            <div className="task-title">{task.title}</div>
                            <div className="task-meta">
                                <span className="task-duration">⏱️ {task.duration} min</span>
                                <span className="task-type-label">{task.type}</span>
                            </div>
                        </div>

                        <div className="task-xp">+{task.duration}XP</div>
                    </div>
                ))}
            </div>

            {/* Completion Message */}
            {status.completed === status.total && (
                <div className="completion-message animate-slide-in-up">
                    <div className="message-icon">🎉</div>
                    <div className="message-content">
                        <h3>STRATEGIC OBJECTIVE COMPLETE</h3>
                        <p>All protocol tasks for this session have been executed successfully.</p>
                    </div>
                </div>
            )}

            {/* Actions */}
            <div className="task-actions">
                <button className="btn btn-outline" onClick={handleMarkAllComplete}>
                    <span>Mark all as complete</span>
                </button>
                <button className="btn btn-ghost" onClick={handleRescheduleTasks}>
                    <span>Reschedule tasks</span>
                </button>
            </div>
        </div>
    );
};

export default DailyTasks;
