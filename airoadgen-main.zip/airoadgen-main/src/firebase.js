// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDpE8MqFN411orLSst3FCbKYD8FqtywwtQ",
    authDomain: "airoadmap-264c1.firebaseapp.com",
    projectId: "airoadmap-264c1",
    storageBucket: "airoadmap-264c1.firebasestorage.app",
    messagingSenderId: "423114903878",
    appId: "1:423114903878:web:75942044bbba0afa20d547"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Initialize Firebase Authentication
export const auth = getAuth(app);

// Google Auth Provider
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
    prompt: 'select_account'
});

export { analytics };
export default app;
