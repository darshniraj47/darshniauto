/**
 * AI ARCHITECT - VANILLA JAVASCRIPT CORE
 * Optimized for high performance and premium interactions.
 */
import './index.css';

const CONFIG = {
    LOCAL_STORAGE_KEYS: {
        USER_DATA: 'architect_user_data',
        ROADMAP_DATA: 'architect_roadmap_data',
        PROGRESS_DATA: 'architect_progress_data'
    }
};

// --- DATA LIBRARIES ---
const CAREER_CATEGORIES = {
    'Tech & Engineering': ['Frontend Developer', 'Backend Developer', 'Full-Stack Developer', 'Mobile App Developer', 'AI / ML Engineer', 'Data Scientist', 'Data Analyst', 'Cybersecurity Analyst', 'Cloud Engineer', 'DevOps Engineer', 'Blockchain Developer', 'Game Developer', 'UI / UX Designer', 'QA / Automation Engineer'],
    'Business & Management': ['Business Analyst', 'Product Manager', 'Project Manager', 'Digital Marketing', 'SEO Specialist', 'Growth Marketer', 'Sales & CRM', 'Entrepreneurship / Startup Founder'],
    'Creative & Media': ['Graphic Designer', 'Motion Designer', 'Video Editor', 'Content Creator', 'Copywriter', 'Social Media Manager', 'Animator'],
    'Core & Professional': ['Mechanical Engineer', 'Electrical Engineer', 'Civil Engineer', 'Architecture', 'Finance & Accounting', 'Banking & Investment', 'Stock Market / Trading', 'HR & Talent Management'],
    'Student & Exam Paths': ['College Student (CSE)', 'College Student (IT)', 'College Student (ECE)', 'College Student (MECH)', 'College Student (CIVIL)', 'School Student (10th)', 'School Student (12th)', 'GATE Preparation', 'UPSC Preparation', 'CAT Preparation', 'GRE Preparation', 'IELTS Preparation']
};

class AIArchitect {
    constructor() {
        this.appEl = document.getElementById('root');
        this.state = {
            currentView: 'welcome',
            activeTab: 'overview',
            onboardingStep: 1,
            userData: null,
            roadmapData: null,
            progressData: {
                streak: 0,
                tasksCompleted: 0,
                xp: 0,
                level: 1,
                completionPercentage: 0,
                weeklyProgress: [0, 0, 0, 0, 0, 0, 0]
            }
        };

        this.init();
    }

    init() {
        this.loadState();
        this.render();
    }

    loadState() {
        const savedUser = localStorage.getItem(CONFIG.LOCAL_STORAGE_KEYS.USER_DATA);
        const savedRoadmap = localStorage.getItem(CONFIG.LOCAL_STORAGE_KEYS.ROADMAP_DATA);
        const savedProgress = localStorage.getItem(CONFIG.LOCAL_STORAGE_KEYS.PROGRESS_DATA);

        if (savedUser) {
            this.state.userData = JSON.parse(savedUser);
            this.state.currentView = 'dashboard';
        }
        if (savedRoadmap) this.state.roadmapData = JSON.parse(savedRoadmap);
        if (savedProgress) this.state.progressData = JSON.parse(savedProgress);
    }

    saveState() {
        localStorage.setItem(CONFIG.LOCAL_STORAGE_KEYS.USER_DATA, JSON.stringify(this.state.userData));
        localStorage.setItem(CONFIG.LOCAL_STORAGE_KEYS.ROADMAP_DATA, JSON.stringify(this.state.roadmapData));
        localStorage.setItem(CONFIG.LOCAL_STORAGE_KEYS.PROGRESS_DATA, JSON.stringify(this.state.progressData));
    }

    setState(update) {
        Object.assign(this.state, update);
        this.saveState();
        this.render();
    }

    render() {
        this.appEl.innerHTML = '';
        switch (this.state.currentView) {
            case 'welcome': this.renderWelcome(); break;
            case 'onboarding': this.renderOnboarding(); break;
            case 'dashboard': this.renderDashboard(); break;
        }
    }

    // --- TEMPLATES ---
    renderWelcome() {
        const container = document.createElement('div');
        container.className = 'welcome animate-fade-in';
        container.style.cssText = 'height: 100vh; display: flex; align-items: center; justify-content: center; text-align: center;';
        container.innerHTML = `
            <div class="welcome-content">
                <div class="welcome-icon" style="font-size: 3rem; margin-bottom: 2rem; color: var(--color-primary);">✧</div>
                <h1 class="welcome-title" style="font-size: clamp(3rem, 10vw, 6rem); font-family: 'Outfit'; font-weight: 200;">AI <span class="text-gradient" style="font-weight: 800; background: var(--gradient-primary); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">ARCHITECT</span></h1>
                <p class="welcome-subtitle" style="color: var(--color-text-secondary); margin-bottom: 3rem;">Premium Strategic Roadmap Orchestration System</p>
                <button class="btn-primary" id="startBtn" style="padding: 1.2rem 3rem; background: white; color: black; border: none; font-weight: 800; cursor: pointer; letter-spacing: 0.1em;">INITIALIZE PROTOCOL</button>
            </div>
        `;
        this.appEl.appendChild(container);
        document.getElementById('startBtn').onclick = () => this.setState({ currentView: 'onboarding' });
    }

    renderOnboarding() {
        const step = this.state.onboardingStep;
        const container = document.createElement('div');
        container.className = 'onboarding animate-fade-in';
        container.style.cssText = 'padding: 4rem 2rem; max-width: 600px; margin: 0 auto;';

        let html = '';
        if (step === 1) {
            html = `
                <h2 style="font-family: 'Outfit'; font-weight: 200; margin-bottom: 1rem;">IDENTIFICATION</h2>
                <p style="font-size: 0.65rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 2rem;">WHO IS ACCESSING THE SYSTEM?</p>
                <div class="form-group" style="margin-bottom: 2rem;">
                    <label style="display: block; font-size: 0.65rem; color: var(--color-text-muted); margin-bottom: 0.5rem;">FULL NAME</label>
                    <input type="text" id="nameInput" class="input-field" style="width: 100%; background: var(--color-surface-elevated); border: 1px solid var(--color-border); color: white; padding: 1rem;" placeholder="Enter name...">
                </div>
                <button class="btn-primary" id="nextBtn" style="width: 100%; padding: 1.2rem; background: white; color: black; border: none; font-weight: 800; cursor: pointer;">CONTINUE</button>
            `;
        } else if (step === 2) {
            html = `
                <h2 style="font-family: 'Outfit'; font-weight: 200; margin-bottom: 1rem;">GENESIS DATA</h2>
                <div class="form-group" style="margin-bottom: 1.5rem;">
                    <label style="display: block; font-size: 0.65rem; color: var(--color-text-muted); margin-bottom: 0.5rem;">SECTOR</label>
                    <select id="catSelect" class="input-field" style="width: 100%; background: var(--color-surface-elevated); border: 1px solid var(--color-border); color: white; padding: 1rem;">
                        ${Object.keys(CAREER_CATEGORIES).map(c => `<option value="${c}">${c}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 2rem;">
                    <label style="display: block; font-size: 0.65rem; color: var(--color-text-muted); margin-bottom: 0.5rem;">SPECIALIZATION</label>
                    <input type="text" id="fieldInput" class="input-field" style="width: 100%; background: var(--color-surface-elevated); border: 1px solid var(--color-border); color: white; padding: 1rem;" placeholder="e.g. Frontend Developer">
                </div>
                <div style="display: flex; gap: 1rem;">
                    <button class="btn-primary" style="flex: 1; background:transparent; color:white; border:1px solid var(--color-border)" id="backBtn">BACK</button>
                    <button class="btn-primary" style="flex: 2; background: white; color: black;" id="genBtn">GENERATE SYSTEM</button>
                </div>
            `;
        }

        container.innerHTML = `<div style="background: var(--color-surface); border: 1px solid var(--color-border); padding: 3rem;">${html}</div>`;
        this.appEl.appendChild(container);

        if (step === 1) {
            document.getElementById('nextBtn').onclick = () => {
                const name = document.getElementById('nameInput').value;
                if (!name) return;
                this.state.userData = { name };
                this.setState({ onboardingStep: 2 });
            };
        } else {
            document.getElementById('backBtn').onclick = () => this.setState({ onboardingStep: 1 });
            document.getElementById('genBtn').onclick = () => {
                const category = document.getElementById('catSelect').value;
                const field = document.getElementById('fieldInput').value;
                if (!field) return;
                this.state.userData = { ...this.state.userData, category, field };
                this.generateRoadmap();
            };
        }
    }

    generateRoadmap() {
        this.state.roadmapData = {
            field: this.state.userData.field,
            monthlyGoals: [{ month: 1, goal: 'Phase I: Structural Foundations', status: 'active' }],
            weeklyFocus: []
        };
        this.setState({ currentView: 'dashboard' });
    }

    renderDashboard() {
        const tab = this.state.activeTab;
        const container = document.createElement('div');
        container.className = 'dashboard-view animate-fade-in';
        container.innerHTML = `
            <nav class="main-nav" style="height: 72px; border-bottom: 1px solid var(--color-border); display: flex; align-items: center; padding: 0 2rem; justify-content: space-between; background: rgba(3,3,3,0.8); backdrop-filter: blur(16px); position: sticky; top: 0;">
                <div class="nav-brand" style="font-family: 'Outfit'; font-weight: 800;">✧ ARCHITECT</div>
                <button id="resetBtn" style="background: none; border: 1px solid var(--color-border); color: var(--color-text-muted); padding: 0.5rem 1rem; font-size: 0.65rem; cursor: pointer; letter-spacing: 0.1em;">RESET SYSTEM</button>
            </nav>
            <main class="main-content" style="padding: 4rem 2rem; max-width: 1200px; margin: 0 auto;">
                <h1 style="font-family: 'Outfit'; font-weight: 200; font-size: 3.5rem; margin-bottom: 1rem;">WELCOME, <span style="font-weight: 800; color: var(--color-primary);">${this.state.userData.name.toUpperCase()}</span></h1>
                <p style="color: var(--color-text-muted); font-size: 1rem; letter-spacing: 0.05em;">STATUS: OPERATIONAL | MISSION: ${this.state.userData.field.toUpperCase()}</p>
                
                <div style="margin-top: 4rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
                    <div style="background: var(--color-surface); border: 1px solid var(--color-border); padding: 2.5rem;">
                        <span style="font-size: 0.65rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.1em;">STREAK</span>
                        <div style="font-size: 2.5rem; font-weight: 800; margin-top: 0.5rem;">${this.state.progressData.streak} DAYS</div>
                    </div>
                    <div style="background: var(--color-surface); border: 1px solid var(--color-border); padding: 2.5rem;">
                        <span style="font-size: 0.65rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.1em;">RANK</span>
                        <div style="font-size: 2.5rem; font-weight: 800; margin-top: 0.5rem;">LEVEL ${this.state.progressData.level}</div>
                    </div>
                    <div style="background: var(--color-surface); border: 1px solid var(--color-border); padding: 2.5rem;">
                        <span style="font-size: 0.65rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.1em;">XP SECURED</span>
                        <div style="font-size: 2.5rem; font-weight: 800; margin-top: 0.5rem;">${this.state.progressData.xp}</div>
                    </div>
                </div>
            </main>
        `;
        this.appEl.appendChild(container);

        document.getElementById('resetBtn').onclick = () => {
            if (confirm('Verify system reset? All data will be purged.')) {
                localStorage.clear();
                window.location.reload();
            }
        };
    }
}

new AIArchitect();
