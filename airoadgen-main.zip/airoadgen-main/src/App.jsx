import { useState, useEffect } from 'react';
import './App.css';

// Auth imports
import { useAuth } from './context/AuthContext';
import { Login, Signup, ForgotPassword } from './components/Auth';

// Import Components
import Welcome from './components/Welcome';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';

function App() {
  // Auth state
  const { currentUser, logout } = useAuth();
  const [authView, setAuthView] = useState('login'); // 'login', 'signup', 'forgot-password'

  // Application State
  const [currentView, setCurrentView] = useState('welcome');
  const [userData, setUserData] = useState(null);
  const [roadmapData, setRoadmapData] = useState(null);
  const [progressData, setProgressData] = useState({
    streak: 0,
    tasksCompleted: 0,
    xp: 0,
    level: 1,
    completionPercentage: 0,
    weeklyProgress: Array(7).fill(0),
  });

  // Load saved data from localStorage
  useEffect(() => {
    const savedUserData = localStorage.getItem('userData');
    const savedRoadmap = localStorage.getItem('roadmapData');
    const savedProgress = localStorage.getItem('progressData');

    if (savedUserData) {
      setUserData(JSON.parse(savedUserData));
      setCurrentView('dashboard');
    }
    if (savedRoadmap) setRoadmapData(JSON.parse(savedRoadmap));
    if (savedProgress) setProgressData(JSON.parse(savedProgress));
  }, []);

  // Save data to localStorage
  useEffect(() => {
    if (userData) localStorage.setItem('userData', JSON.stringify(userData));
  }, [userData]);

  useEffect(() => {
    if (roadmapData) localStorage.setItem('roadmapData', JSON.stringify(roadmapData));
  }, [roadmapData]);

  useEffect(() => {
    localStorage.setItem('progressData', JSON.stringify(progressData));
  }, [progressData]);

  // Handle onboarding completion
  const handleOnboardingComplete = (data) => {
    setUserData(data);
    generateRoadmap(data);
    setCurrentView('dashboard');
  };

  // Generate AI Roadmap (Strategic Integration)
  const generateRoadmap = (data) => {
    const weeklyFocus = generateWeeklyFocus(data);
    const roadmap = {
      field: data.field,
      level: data.level,
      duration: data.duration,
      dailyTime: data.dailyTime,
      monthlyGoals: generateMonthlyGoals(data),
      weeklyFocus: weeklyFocus,
      dailyTasks: generateDailyTasks(data, weeklyFocus),
      milestones: generateMilestones(data),
      projects: generateProjects(data),
      certifications: generateCertifications(data),
    };
    setRoadmapData(roadmap);
  };

  // Helper functions for roadmap generation
  const generateMonthlyGoals = (data) => {
    const months = parseInt(data.duration) || 3;
    const goals = [];

    const fieldGoals = {
      'Frontend Developer': [
        'Phase I: Master Structural Engineering & Semantic Logic',
        'Phase II: Architect Dynamic UI Systems & Component Logic',
        'Phase III: Optimize Performance & Enterprise Deployment',
      ],
      'Backend Developer': [
        'Phase I: Construct Scalable API Architecture & Database Schema',
        'Phase II: Implement Advanced Security & Distributed Logic',
        'Phase III: Orchestrate Cloud Infrastructure & DevOps Pipelines',
      ],
      'AI / ML Engineer': [
        'Phase I: Establish Mathematical Prowess & Data Engineering Foundation',
        'Phase II: Develop Neural Architectures & Vision/NLP Systems',
        'Phase III: Master MLOps, Model Deployment & System Ethics',
      ],
      'GATE Preparation': [
        'Phase I: Foundation in Math, Digital & Logic Systems',
        'Phase II: Core CS Algorithms, OS & Database Mastery',
        'Phase III: Advanced Networks, Theory & Mock Analysis',
      ],
      'UPSC Preparation': [
        'Phase I: GS Static Core (Hist, Geo, Polity) Foundations',
        'Phase II: Social Ethics, Economy & International Strat',
        'Phase III: Current Affairs Mastery & Answer Writing',
      ],
      'CAT Preparation': [
        'Phase I: Quantitative Aptitude & Reading foundations',
        'Phase II: DILR Logic & Advanced Data Interpretation',
        'Phase III: Accuracy Scaling & Mock Strategy Analysis',
      ],
      'GRE Preparation': [
        'Phase I: Verbal Mastery & Vocabulary Engineering',
        'Phase II: Quant Logic & Geometric Proof Systems',
        'Phase III: Analytical Writing & Full Mock Protocols',
      ],
      'IELTS Preparation': [
        'Phase I: Listening & Reading Framework Mastery',
        'Phase II: Writing Structures & Speaking Fluency',
        'Phase III: Mock Simulations & Lexical Band Scaling',
      ],
      'School Student (10th)': [
        'Phase I: Strengthening Math & Science Fundamentals',
        'Phase II: Humanities Context & Critical Analysis',
        'Phase III: Board Exam Excellence & Full Prep Sets',
      ],
      'School Student (12th)': [
        'Phase I: Specialized Science/Math Domain Deep Dive',
        'Phase II: Advanced Organic Logic & Physics Proofs',
        'Phase III: Preparation for Finals & Professional Entry',
      ]
    };

    const defaultGoals = [
      'Phase I: Core Foundations & System Setup',
      'Phase II: Advanced Implementation & Technical Mastery',
      'Phase III: Production Deployment & Optimization',
    ];

    const selectedGoals = fieldGoals[data.field] || fieldGoals[data.category] || defaultGoals;

    for (let i = 0; i < months; i++) {
      goals.push({
        month: i + 1,
        goal: selectedGoals[i % selectedGoals.length],
        status: i === 0 ? 'active' : 'upcoming',
      });
    }

    return goals;
  };

  // Ultra-High-Precision Curriculum Engine (Exactly 12 Units)
  const generateWeeklyFocus = (data) => {
    // Deep-Search Curriculum Library
    const curriculumLibrary = {
      // --- SCHOOL & ACADEMIC PATHS ---
      'School Student (10th)': [
        { focus: 'Math: Real Numbers & Polynomials', topics: ['Fundamental Theorem of Arithmetic', 'Zeroes of a Polynomial', 'Algebraic Methods'], link: 'https://ncert.nic.in/textbook.php?jemh1=0-15' },
        { focus: 'Science: Chemical Reactions', topics: ['Balanced Equations', 'Oxidation & Reduction', 'Acids, Bases & Salts'], link: 'https://ncert.nic.in/textbook.php?jesc1=0-16' },
        { focus: 'History: Nationalism in Europe & India', topics: ['The French Revolution', 'Satyagraha Movement', 'Civil Disobedience'], link: 'https://ncert.nic.in/textbook.php?jess3=0-5' },
        { focus: 'Geo: Resources & Development', topics: ['Soil Classification', 'Water Resources', 'Mineral Logic'], link: 'https://ncert.nic.in/textbook.php?jess1=0-7' },
        { focus: 'Math: Quadratic Equations & AP', topics: ['Nature of Roots', 'Arithmetic Progressions', 'Sum of N Terms'], link: 'https://ncert.nic.in/textbook.php?jemh1=4-5' },
        { focus: 'Science: Life Processes', topics: ['Nutrition & Respiration', 'Transportation in Humans', 'Excretion'], link: 'https://ncert.nic.in/textbook.php?jesc1=6-16' },
        { focus: 'Civics: Power Sharing & Federalism', topics: ['Belgian vs Sri Lankan Model', 'Decentralization in India', 'Political Parties'], link: 'https://ncert.nic.in/textbook.php?jess4=0-5' },
        { focus: 'Math: Triangles & Trigonometry', topics: ['Similarity of Triangles', 'Trigonometric Ratios', 'Heights & Distances'], link: 'https://ncert.nic.in/textbook.php?jemh1=6-9' },
        { focus: 'Science: Light & Human Eye', topics: ['Reflection & Refraction', 'Spherical Mirrors', 'Dispersion of Light'], link: 'https://ncert.nic.in/textbook.php?jesc1=10-16' },
        { focus: 'Eco: Development & Sectors', topics: ['National Development', 'Primary/Secondary/Tertiary', 'Money & Credit'], link: 'https://ncert.nic.in/textbook.php?jess2=0-5' },
        { focus: 'Science: Electricity & Magnetism', topics: ['Ohm\'s Law', 'Magnetic Field Lines', 'Electromagnetic Induction'], link: 'https://ncert.nic.in/textbook.php?jesc1=12-16' },
        { focus: 'Math: Statistics & Probability', topics: ['Mean, Median, Mode', 'Cumulative Frequency', 'Theoretical Probability'], link: 'https://ncert.nic.in/textbook.php?jemh1=14-15' }
      ],
      'School Student (12th)': [
        { focus: 'Math: Relations & Functions', topics: ['Types of Relations', 'Inverse Trig Functions', 'Binary Operations'], link: 'https://ncert.nic.in/textbook.php?kemh1=0-6' },
        { focus: 'Physics: Electrostatics', topics: ['Coulomb\'s Law', 'Electric Potential', 'Capacitance Logic'], link: 'https://ncert.nic.in/textbook.php?keph1=0-8' },
        { focus: 'Chemistry: Solutions & Electrochemistry', topics: ['Molarity & Molality', 'Nernst Equation', 'Fuel Cells'], link: 'https://ncert.nic.in/textbook.php?kech1=0-9' },
        { focus: 'Biology: Reproduction & Genetics', topics: ['Human Reproduction', 'Mendelian Inheritance', 'DNA Replication'], link: 'https://ncert.nic.in/textbook.php?kebo1=0-16' },
        { focus: 'Math: Calculus - Derivatives', topics: ['Chain Rule', 'Implicit Differentiation', 'Maxims & Minima'], link: 'https://ncert.nic.in/textbook.php?kemh1=5-6' },
        { focus: 'Physics: Current Electricity', topics: ['Kirchhoff\'s Laws', 'Wheatstone Bridge', 'Potentiometer'], link: 'https://ncert.nic.in/textbook.php?keph1=3-8' },
        { focus: 'Chemistry: P-Block & Coordination', topics: ['Noble Gases', 'Ligand Field Theory', 'Isomerism'], link: 'https://ncert.nic.in/textbook.php?kech1=7-9' },
        { focus: 'Math: Calculus - Integration', topics: ['Definite Integrals', 'Area Under Curves', 'Differential Equations'], link: 'https://ncert.nic.in/textbook.php?kemh2=0-6' },
        { focus: 'Physics: Optics & Atoms', topics: ['Wave Optics', 'Photoelectric Effect', 'Nuclear Logic'], link: 'https://ncert.nic.in/textbook.php?keph2=0-7' },
        { focus: 'Chemistry: Organic Compounds', topics: ['Haloalkanes', 'Carboxylic Acids', 'Biomolecules'], link: 'https://ncert.nic.in/textbook.php?kech2=0-7' },
        { focus: 'Biology: Ecology & Biotech', topics: ['PCR Technology', 'Ecosystem Dynamics', 'Biodiversity'], link: 'https://ncert.nic.in/textbook.php?kebo1=11-16' },
        { focus: 'Math: Vectors & 3D Geometry', topics: ['Dot/Cross Product', 'Shortest Distance', 'Probability Logic'], link: 'https://ncert.nic.in/textbook.php?kemh2=10-13' }
      ],

      // --- COMPETITIVE EXAMS ---
      'GATE Preparation': [
        { focus: 'Discrete Math & Linear Algebra', topics: ['Propositional Logic', 'Eigenvalues', 'Combinatorics'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Digital Logic & Architecture', topics: ['Boolean Min', 'Instruction Pipelining', 'Memory hierarchy'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Programming & Data Structures', topics: ['C Programming', 'Recursion', 'Linked Lists', 'Trees'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Algorithms', topics: ['Asymptotic Analysis', 'Sorting & Searching', 'Dynamic Programming'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Theory of Computation', topics: ['Regular Languages', 'Context-free Grammars', 'Turing Machines'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Compiler Design', topics: ['Lexical Analysis', 'Parsing', 'Runtime Environments'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Operating System', topics: ['Processes & Threads', 'CPU Scheduling', 'Deadlocks', 'Memory'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Databases', topics: ['Relational Model', 'SQL', 'Normalization', 'Transactions'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Computer Networks', topics: ['OSI & TCP/IP Stack', 'IP Addressing', 'Routing Protocols'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'Prob & Stats', topics: ['Bayes Theorem', 'Random Variables', 'Uniform & Normal Dist'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'General Aptitude (Numerical)', topics: ['Ratios', 'Percentages', 'Permutations', 'Logics'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' },
        { focus: 'General Aptitude (Verbal)', topics: ['Grammar', 'Vocabulary', 'Critical Reasoning'], link: 'https://gate.iitr.ac.in/cs-syllabus.html' }
      ],
      'UPSC Preparation': [
        { focus: 'Indian Polity & Governance', topics: ['Constitution', 'Parliament', 'Local Government'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Indian History & Culture', topics: ['Ancient', 'Medieval', 'Modern Struggle'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Geography (Indian & World)', topics: ['Physical', 'Human Geo', 'Economic Geo'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Indian Economy', topics: ['Development', 'Planning', 'Budgeting'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Environment & Ecology', topics: ['Biodiversity', 'Climate Change'], link: 'https://www.upsc.gov.in/' },
        { focus: 'General Science', topics: ['Physics', 'Chemistry', 'Biology Focus'], link: 'https://www.upsc.gov.in/' },
        { focus: 'International Relations', topics: ['India & Neighbors', 'Global Bodies'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Social Justice & Ethics', topics: ['Welfare Schemes', 'Ethical Governance'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Current Affairs I', topics: ['State & National Importance'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Current Affairs II', topics: ['Global Summits', 'Treaties'], link: 'https://www.upsc.gov.in/' },
        { focus: 'CSAT: Reasoning & Aptitude', topics: ['Logic', 'Data Interpretation'], link: 'https://www.upsc.gov.in/' },
        { focus: 'Answer Writing & Revision', topics: ['Mains Strategy', 'Essay Writing'], link: 'https://www.upsc.gov.in/' }
      ],
      'CAT Preparation': [
        { focus: 'VARC: Reading Comprehension', topics: ['Critical Reasoning', 'Main Idea Identification'], link: 'https://iimcat.ac.in/' },
        { focus: 'VARC: Verbal Ability', topics: ['Para-jumbles', 'Summary Type Questions'], link: 'https://iimcat.ac.in/' },
        { focus: 'DILR: Logic Games', topics: ['Arrangements', 'Team Formations'], link: 'https://iimcat.ac.in/' },
        { focus: 'DILR: Data Interpretation', topics: ['Bar Graphs', 'Pie Charts', 'Venn Diagrams'], link: 'https://iimcat.ac.in/' },
        { focus: 'QA: Number Systems', topics: ['HCF/LCM', 'Divisibility Rules'], link: 'https://iimcat.ac.in/' },
        { focus: 'QA: Arithmetic', topics: ['Percentages', 'Profit & Loss', 'Ratios'], link: 'https://iimcat.ac.in/' },
        { focus: 'QA: Algebra', topics: ['Linear Equations', 'Quadratic Loops'], link: 'https://iimcat.ac.in/' },
        { focus: 'QA: Geometry', topics: ['Circles', 'Triangles', 'Mensuration'], link: 'https://iimcat.ac.in/' },
        { focus: 'QA: Modern Math', topics: ['Permutations', 'Combinations', 'Probability'], link: 'https://iimcat.ac.in/' },
        { focus: 'Mock Strategy I', topics: ['Initial Mock Analysis'], link: 'https://iimcat.ac.in/' },
        { focus: 'Mock Strategy II', topics: ['Speed vs Accuracy Optimization'], link: 'https://iimcat.ac.in/' },
        { focus: 'Final Revision', topics: ['Formula Recap', 'Time management'], link: 'https://iimcat.ac.in/' }
      ],

      // --- TECH & ENGINEERING ---
      'Frontend Developer': [
        { focus: 'Unit 1: Semantic HTML5 & Accessibility', topics: ['W3C Standards', 'ARIA Roles', 'Semantic Architecture'], link: 'https://developer.mozilla.org/en-US/docs/Learn/HTML' },
        { focus: 'Unit 2: CSS Grid & Layout Systems', topics: ['CSS Grid Masterclass', 'Flexbox Patterns', 'CSS Variables'], link: 'https://web.dev/learn/css/' },
        { focus: 'Unit 3: Modern JS (ES6+) Foundations', topics: ['Execution Context', 'Closures & Scope', 'Async/Await'], link: 'https://javascript.info/' },
        { focus: 'Unit 4: React Component Architecture', topics: ['Virtual DOM', 'JSX Deep Dive', 'Component Lifecycle'], link: 'https://react.dev/learn' },
        { focus: 'Unit 5: Advanced State Orchestration', topics: ['React Hooks Ecosystem', 'Context API', 'State Machines'], link: 'https://react.dev/reference/react' },
        { focus: 'Unit 6: Client-Side Routing & Navigation', topics: ['React Router v7', 'Dynamic Route Guards', 'Data Fetching'], link: 'https://reactrouter.com/en/main' },
        { focus: 'Unit 7: UI Frameworks & Tailwind JIT', topics: ['Utility-First Design', 'Custom Config', 'Theme Design'], link: 'https://tailwindcss.com/docs' },
        { focus: 'Unit 8: API Integration & Data Sync', topics: ['SWR/TanStack Query', 'Optimistic Updates', 'Error Boundaries'], link: 'https://tanstack.com/query/latest' },
        { focus: 'Unit 9: Testing & Quality Assurance', topics: ['Vitest', 'Testing Library', 'E2E with Playwright'], link: 'https://vitest.dev/guide/' },
        { focus: 'Unit 10: Performance Engineering', topics: ['Bundle Analysis', 'Code Splitting', 'Image Optimization'], link: 'https://web.dev/vitals/' },
        { focus: 'Unit 11: Build Tools & Deployment', topics: ['Vite Configuration', 'CI/CD Pipelines', 'Edge Deployment'], link: 'https://vitejs.dev/guide/' },
        { focus: 'Unit 12: SEO & Meta Strategies', topics: ['Open Graph Logic', 'Schema.org', 'Server Components'], link: 'https://nextjs.org/docs/advanced-features/seo-optimization' }
      ],
      'Backend Developer': [
        { focus: 'Node.js Runtime & Internals', topics: ['Event Loop', 'V8 Engine', 'Buffers & Streams'], link: 'https://nodejs.org/en/docs/guides/event-loop-timers-and-nexttick/' },
        { focus: 'Advanced JavaScript (ES2024)', topics: ['Top-level Await', 'Modules', 'Structural Clone'], link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript' },
        { focus: 'Restful API Design Mastery', topics: ['HATEOAS', 'Versioning Strategies', 'Status Codes'], link: 'https://restfulapi.net/' },
        { focus: 'Relational Database Design', topics: ['ACID Properties', 'Indexing', 'Normalization'], link: 'https://www.postgresql.org/docs/' },
        { focus: 'NoSQL & Scaling Strategies', topics: ['CAP Theorem', 'Sharding', 'Replication'], link: 'https://www.mongodb.com/docs/' },
        { focus: 'Authentication Engineering', topics: ['OAuth2', 'JWT Logic', 'OpenID Connect'], link: 'https://auth0.com/docs' },
        { focus: 'Server-Side Testing', topics: ['Jest', 'Supertest', 'Integration Patterns'], link: 'https://jestjs.io/' },
        { focus: 'Infrastructure & DevOps Core', topics: ['Docker Internals', 'Kubernetes Architecture'], link: 'https://docs.docker.com/' },
        { focus: 'System Design Patterns', topics: ['MVC', 'Microservices', 'Event-Driven'], link: 'https://microservices.io/' },
        { focus: 'Security & Integrity', topics: ['OWASP Top 10', 'Rate Limiting', 'Encryption'], link: 'https://owasp.org/www-project-top-ten/' },
        { focus: 'Performance & Caching', topics: ['Redis Patterns', 'CDN Edge Logic'], link: 'https://redis.io/documentation' },
        { focus: 'Enterprise Deployment', topics: ['AWS/GCP Logic', 'CI/CD Pipeline Design'], link: 'https://aws.amazon.com/certification/' }
      ],
      'AI / ML Engineer': [
        { focus: 'Unit 1: Mathematical Foundations', topics: ['Linear Algebra', 'Multi-variable Calculus', 'Vector Spaces'], link: 'https://www.khanacademy.org/math/linear-algebra' },
        { focus: 'Unit 2: Statistical Inferrence', topics: ['Bayesian Theory', 'Distributions', 'Hypothesis Testing'], link: 'https://www.statlearning.com/' },
        { focus: 'Unit 3: Python for Data Engineering', topics: ['NumPy Vectorization', 'Pandas Analytics', 'Scikit-Learn'], link: 'https://pandas.pydata.org/docs/' },
        { focus: 'Unit 4: Classic Machine Learning', topics: ['Regression Engines', 'Decision Forests', 'SVM Logic'], link: 'https://scikit-learn.org/stable/' },
        { focus: 'Unit 5: Deep Learning Foundations', topics: ['Neural Architecture', 'Backpropagation', 'Activation Logic'], link: 'https://www.deeplearning.ai/' },
        { focus: 'Unit 6: Computer Vision (CNN)', topics: ['Convolutional Layers', 'Object Detection', 'Image Processing'], link: 'https://pytorch.org/tutorials/' },
        { focus: 'Unit 7: NLP & Sequence Models', topics: ['RNNs & LSTMs', 'Word Embeddings', 'Transformer Core'], link: 'https://huggingface.co/docs/transformers/index' },
        { focus: 'Unit 8: Generative AI & LLMs', topics: ['Attention Mechanism', 'Fine-tuning LLMs', 'Diffusion Models'], link: 'https://fullstackdeeplearning.com/' },
        { focus: 'Unit 9: MLOps Frameworks', topics: ['Model Versioning', 'Artifact Management', 'Deployment Gates'], link: 'https://ml-ops.org/' },
        { focus: 'Unit 10: Model Quantization', topics: ['Inference Optimization', 'ONNX Runtime', 'TensorRT'], link: 'https://onnx.ai/' },
        { focus: 'Unit 11: Ethics & AI Governance', topics: ['Bias Mitigation', 'Explainable AI', 'Safety Protocols'], link: 'https://www.alignmentforum.org/' },
        { focus: 'Unit 12: Capstone System Deployment', topics: ['Inference Endpoints', 'Monitoring Dashboards', 'Scalability'], link: 'https://www.bentoml.com/' }
      ],
      'Cybersecurity Analyst': [
        { focus: 'Networking Fundamentals', topics: ['TCP/IP Model', 'OSI Layers', 'Packet Analysis'], link: 'https://www.comptia.org/certifications/network' },
        { focus: 'OS Security (Linux/Windows)', topics: ['Kernel Hardening', 'File Permissions'], link: 'https://www.linuxfoundation.org/' },
        { focus: 'Threat Landscape', topics: ['Malware Types', 'Access Attack Vectors'], link: 'https://www.crowdstrike.com/cybersecurity-101/' },
        { focus: 'Vulnerability Assessment', topics: ['CVSS Scoring', 'Scanning Tools'], link: 'https://www.tenable.com/products/nessus' },
        { focus: 'Identity & Access Management', topics: ['RBAC', 'MFA Protocols', 'SSO'], link: 'https://www.okta.com/intro-to-iam/' },
        { focus: 'Cryptography Core', topics: ['AES/RSA Logic', 'Hashing', 'PKI'], link: 'https://www.cryptool.org/' },
        { focus: 'Incident Response Protocol', topics: ['Phase Logic', 'Digital Forensics'], link: 'https://www.sans.org/' },
        { focus: 'Network Security Tools', topics: ['Firewalls', 'IDS/IPS', 'WAF Configuration'], link: 'https://www.fortinet.com/' },
        { focus: 'Application Security', topics: ['OWASP Top 10', 'Securing APIs'], link: 'https://owasp.org/' },
        { focus: 'Cloud Security Architecture', topics: ['AWS Shared Responsibility', 'IAM'], link: 'https://aws.amazon.com/security/' },
        { focus: 'Governance & Compliance', topics: ['GDPR', 'HIPAA', 'ISO 27001'], link: 'https://www.iso.org/isoiec-27001-information-security.html' },
        { focus: 'Penetration Testing Basics', topics: ['Footprinting', 'Exploitation'], link: 'https://www.offensive-security.com/' }
      ],
      'Data Scientist': [
        { focus: 'Statistical Foundations', topics: ['Probablity', 'Distributions', 'Inference'], link: 'https://www.khanacademy.org/math/statistics-probability' },
        { focus: 'Python Data Ecosystem', topics: ['NumPy', 'Pandas', 'Matplotlib'], link: 'https://docs.python.org/3/' },
        { focus: 'Data Wrangling mastery', topics: ['Cleaning', 'Merging', 'Transformation'], link: 'https://pandas.pydata.org/' },
        { focus: 'Exploratory Analysis (EDA)', topics: ['Boxplots', 'Correlation Matrix'], link: 'https://seaborn.pydata.org/' },
        { focus: 'Supervised Learning Algorithms', topics: ['Linear Regression', 'XGBoost'], link: 'https://scikit-learn.org/' },
        { focus: 'Unsupervised Learning', topics: ['Clustering', 'PCA', 'Anomalies'], link: 'https://scikit-learn.org/' },
        { focus: 'Neural Network Basics', topics: ['Perceptrons', 'Backpropagation'], link: 'https://www.tensorflow.org/' },
        { focus: 'Deep Learning Specialization', topics: ['Computer Vision', 'NLP'], link: 'https://pytorch.org/' },
        { focus: 'Big Data Frameworks', topics: ['Spark', 'Hadoop Ecosystem'], link: 'https://spark.apache.org/' },
        { focus: 'Model Deployment Logic', topics: ['Flask/FastAPI API', 'Docker'], link: 'https://fastapi.tiangolo.com/' },
        { focus: 'Data Storytelling', topics: ['Tableau/PowerBI', 'Dashboards'], link: 'https://www.tableau.com/' },
        { focus: 'Ethical & Responsible AI', topics: ['Safety', 'Fairness', 'Privacy'], link: 'https://www.partnershiponai.org/' }
      ],
      'Full-Stack Developer': [
        { focus: 'Frontend Architecture & SEO', topics: ['Semantic HTML', 'Next.js Routing', 'Core Web Vitals'], link: 'https://nextjs.org/docs' },
        { focus: 'Advanced CSS & Design Systems', topics: ['Tailwind JIT', 'Framer Motion', 'Accessibility'], link: 'https://tailwindcss.com/docs' },
        { focus: 'State Orchestration', topics: ['Redux Toolkit', 'Zustand', 'React Query'], link: 'https://tanstack.com/query/latest' },
        { focus: 'Backend Systems (Node/Python)', topics: ['Runtime Internals', 'Async Patterns', 'Streams'], link: 'https://nodejs.org/docs' },
        { focus: 'API Engineering (GraphQL/REST)', topics: ['Apollo Server', 'HATEOAS', 'Rate Limiting'], link: 'https://graphql.org/learn/' },
        { focus: 'Database Logic & Scalability', topics: ['PostgreSQL Indexing', 'Redis Caching', 'NoSQL'], link: 'https://www.postgresql.org/docs/' },
        { focus: 'Authentication & Identity', topics: ['Auth.js (NextAuth)', 'JWT', 'RBAC Patterns'], link: 'https://authjs.dev/' },
        { focus: 'Testing & QA Automation', topics: ['Playwright', 'Jest', 'Supertest'], link: 'https://playwright.dev/' },
        { focus: 'DevOps & Cloud (AWS/GCP)', topics: ['Docker', 'Terraform (IaC)', 'CI/CD Pipelines'], link: 'https://docs.aws.amazon.com/' },
        { focus: 'Monitoring & Observability', topics: ['Sentry', 'Log Management', 'Performance Audits'], link: 'https://docs.sentry.io/' },
        { focus: 'Security Engineering', topics: ['OWASP Security', 'CORS/CSP', 'Audit Logs'], link: 'https://cheatsheetseries.owasp.org/' },
        { focus: 'Deployment & Edge Logic', topics: ['Vercel/Netlify', 'Serverless Functions', 'Edge Runtime'], link: 'https://vercel.com/docs' }
      ],
      'Mobile App Developer': [
        { focus: 'Mobile Architecture (React Native/Flutter)', topics: ['Component Lifecycle', 'Bridge vs Fabric'], link: 'https://reactnative.dev/docs/getting-started' },
        { focus: 'Mobile UI/UX Design Systems', topics: ['Material Design', 'Human Interface Guidelines'], link: 'https://developer.apple.com/design/human-interface-guidelines/' },
        { focus: 'Native Features Integration', topics: ['Camera API', 'Biometrics', 'Location Services'], link: 'https://docs.expo.dev/' },
        { focus: 'State & Data Management', topics: ['AsyncStorage', 'SQLite', 'Offline-First Logic'], link: 'https://tanstack.com/query/latest' },
        { focus: 'Performance Optimization', topics: ['FlatList Optimization', 'Bundle Sizing', 'Profiling'], link: 'https://reactnative.dev/docs/performance' },
        { focus: 'Authentication & Security', topics: ['Firebase Auth', 'Secure Storage', 'SSL Pinning'], link: 'https://firebase.google.com/docs/auth' },
        { focus: 'App Store Guidelines & SEO', topics: ['ASO Strategy', 'Metadata', 'Compliance'], link: 'https://developer.mozilla.org/en-US/docs/Glossary/SEO' },
        { focus: 'CI/CD for Mobile', topics: ['Fastlane', 'GitHub Actions', 'CodePush'], link: 'https://docs.fastlane.tools/' },
        { focus: 'Testing & Debugging', topics: ['Detox E2E', 'React Native Testing Library'], link: 'https://wix.github.io/Detox/' },
        { focus: 'Push Notifications & Deep Linking', topics: ['FCM', 'Universal Links', 'Branch.io'], link: 'https://firebase.google.com/docs/cloud-messaging' },
        { focus: 'Cross-Platform Deployment', topics: ['TestFlight', 'Google Play Console'], link: 'https://play.google.com/console/about/' },
        { focus: 'Advanced Mobile Features', topics: ['WebViews', 'Background Tasks', 'Apple Pay/Google Pay'], link: 'https://stripe.com/docs/apple-pay' }
      ],
      'DevOps Engineer': [
        { focus: 'Infrastructure as Code (IaC)', topics: ['Terraform', 'CloudFormation', 'Ansible'], link: 'https://www.terraform.io/docs' },
        { focus: 'Containerization & Orchestration', topics: ['Docker', 'Kubernetes Architecture', 'Helm'], link: 'https://kubernetes.io/docs/home/' },
        { focus: 'CI/CD Pipeline Architecture', topics: ['Jenkins', 'GitLab CI', 'GitHub Actions'], link: 'https://docs.github.com/en/actions' },
        { focus: 'Cloud Provider Mastery (AWS/Azure)', topics: ['EC2/S3', 'IAM Roles', 'VPC Networking'], link: 'https://aws.amazon.com/whitepapers/' },
        { focus: 'Monitoring & Logging', topics: ['Prometheus & Grafana', 'ELK Stack', 'Datadog'], link: 'https://prometheus.io/docs/introduction/overview/' },
        { focus: 'Security (DevSecOps)', topics: ['SAST/DAST', 'Vault Secret Management', 'Falco'], link: 'https://www.hashicorp.com/products/vault' },
        { focus: 'Networking & Load Balancing', topics: ['Nginx', 'Route53', 'Service Mesh (Istio)'], link: 'https://istio.io/latest/docs/' },
        { focus: 'Linux Systems & Scripting', topics: ['Bash', 'Python for DevOps', 'Kernel Tuning'], link: 'https://linuxjourney.com/' },
        { focus: 'Site Reliability Engineering (SRE)', topics: ['SLIs/SLOs', 'Error Budgets', 'Incident Response'], link: 'https://sre.google/sre-book/table-of-contents/' },
        { focus: 'Serverless Infrastructure', topics: ['AWS Lambda', 'Cloud Functions', 'Edge Logic'], link: 'https://www.serverless.com/framework/docs' },
        { focus: 'Artifact Management', topics: ['Artifactory', 'Docker Registry Administration'], link: 'https://jfrog.com/artifactory/' },
        { focus: 'Cost Optimization & FinOps', topics: ['Cloud Health', 'Spot Instance Strategy'], link: 'https://www.finops.org/introduction/what-is-finops/' }
      ],
      'GRE Preparation': [
        { focus: 'Verbal: Critical Reasoning', topics: ['Argument Structure', 'Assumption Identification'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Verbal: Text Completion', topics: ['Context Clues', 'Vocabulary in Context'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Verbal: Sentence Equivalence', topics: ['Synonym Identification', 'Semantic Logic'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Quant: Arithmetic & Number Prop', topics: ['Primes', 'Divisibility', 'Ratios'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Quant: Algebra', topics: ['Linear & Quadratic Equations', 'Inequalities'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Quant: Geometry', topics: ['Circles', 'Polygons', '3D Figures'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Quant: Data Analysis', topics: ['Normal Distribution', 'Probability', 'Stats'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Analytical Writing (AWA): Issue', topics: ['Complex Argumentation', 'Structuring Essays'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Analytical Writing (AWA): Argument', topics: ['Logical Fallacy Detection'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' },
        { focus: 'Full-Length Mock I', topics: ['Time management under pressure'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare/powerprep.html' },
        { focus: 'Full-Length Mock II', topics: ['Weak area identification and strategy'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare/powerprep.html' },
        { focus: 'Final Strategy & Revision', topics: ['Formula Recap', 'Vocabulary Blitz'], link: 'https://www.ets.org/gre/test-takers/general-test/prepare.html' }
      ],
      'IELTS Preparation': [
        { focus: 'Listening: Form & Note Completion', topics: ['Predicting Information', 'Spelling Logic'], link: 'https://www.ielts.org/for-test-takers/how-to-prepare' },
        { focus: 'Listening: Section 3 & 4 Mastery', topics: ['Academic Discussions', 'Monologues'], link: 'https://www.ielts.org/for-test-takers/how-to-prepare' },
        { focus: 'Reading: Skimming & Scanning', topics: ['Heading Matching', 'True/False/Not Given'], link: 'https://www.ielts.org/for-test-takers/sample-test-questions' },
        { focus: 'Reading: Multiple Choice & Summary', topics: ['Cohesive Devices', 'Context Logic'], link: 'https://www.ielts.org/for-test-takers/sample-test-questions' },
        { focus: 'Writing Task 1: Data Description', topics: ['Bar/Line/Pie Chart Analysis'], link: 'https://www.britishcouncil.in/exam/ielts/prepare' },
        { focus: 'Writing Task 2: Essay Structure', topics: ['Opinion, Discussion, Solution Essays'], link: 'https://www.britishcouncil.in/exam/ielts/prepare' },
        { focus: 'Writing task 2: Grammar & Lexis', topics: ['Vocabulary Range', 'Complex Sentences'], link: 'https://www.britishcouncil.in/exam/ielts/prepare' },
        { focus: 'Speaking Part 1: Personal Interests', topics: ['Fluency & Coherence', 'Pronunciation'], link: 'https://www.ielts.org/for-test-takers/how-to-prepare' },
        { focus: 'Speaking Part 2 & 3: Discussion', topics: ['Extended Responses', 'Topic Development'], link: 'https://www.ielts.org/for-test-takers/how-to-prepare' },
        { focus: 'Mock Exam: Full Simulated Test', topics: ['Timing strategy for all sections'], link: 'https://www.ielts.org/for-test-takers/sample-test-questions' },
        { focus: 'IELTS Vocabulary Blitz', topics: ['Academic Word List', 'Collocations'], link: 'https://www.ielts.org/for-test-takers/how-to-prepare' },
        { focus: 'Final Exam Success Strategy', topics: ['Mental Prep', 'Exam Day Protocols'], link: 'https://www.ielts.org/for-test-takers/how-to-prepare' }
      ],
      'Digital Marketing': [
        { focus: 'SEO (Search Engine Optimization)', topics: ['On-Page SEO', 'Technical SEO', 'Keyword Logic'], link: 'https://learning.google/search/seo/' },
        { focus: 'Content Marketing Strategy', topics: ['Blogging', 'Lead Magnets', 'Editorial Calendars'], link: 'https://academy.hubspot.com/courses/content-marketing' },
        { focus: 'Social Media Management', topics: ['Platform Algorithms', 'Community Building'], link: 'https://www.facebook.com/business/learn' },
        { focus: 'Paid Advertising (SEM/PPC)', topics: ['Google Ads', 'Meta Ads Manager', 'Bidding'], link: 'https://skillshop.exceedlms.com/student/catalog/browse' },
        { focus: 'Email Marketing & Automation', topics: ['Drip Campaigns', 'CTR Optimization', 'Segmentation'], link: 'https://mailchimp.com/resources/' },
        { focus: 'Data Analytics & Reporting', topics: ['Google Analytics 4 (GA4)', 'GTM Setup'], link: 'https://analytics.google.com/analytics/academy/' },
        { focus: 'Conversion Rate Optimization (CRO)', topics: ['A/B Testing', 'Landing Page Psych'], link: 'https://cxl.com/blog/' },
        { focus: 'Affiliate & Influencer Marketing', topics: ['Brand Partnerships', 'Affiliate Networks'], link: 'https://www.shopify.com/blog/affiliate-marketing' },
        { focus: 'Digital Branding & PR', topics: ['Voice & Tone', 'Crisis Management', 'Backlinks'], link: 'https://www.semrush.com/academy/' },
        { focus: 'Growth Hacking Techniques', topics: ['AARRR Funnel', 'Viral Loops', 'Scale Logic'], link: 'https://growthhackers.com/' },
        { focus: 'Video & Visual Marketing', topics: ['YouTube SEO', 'Vertical Video Strategy (Shorts)'], link: 'https://creatoracademy.youtube.com/' },
        { focus: 'Final Campaign Capstone', topics: ['Full Strategy Deployment', 'Reporting'], link: 'https://academy.hubspot.com/' }
      ]
    };

    // Fallback Library for undefined fields
    const sectorDefaults = {
      'Tech & Engineering': [
        { focus: 'Industry Foundations', topics: ['System Principles', 'Core Terminology', 'Environment Setup'], link: 'https://roadmap.sh/' },
        { focus: 'Structural Architecture', topics: ['Logic Flow Mapping', 'Structural Planning', 'Logic'], link: 'https://roadmap.sh/' },
        { focus: 'Technical Implementation', topics: ['Implementation A', 'Integration', 'Initial'], link: 'https://roadmap.sh/' },
        { focus: 'Advanced Logic Systems', topics: ['Advanced Optimization', 'Theory', 'Preparation'], link: 'https://roadmap.sh/' },
        { focus: 'Validation & Testing', topics: ['Quality Standards', 'Edge Cases', 'Verification'], link: 'https://roadmap.sh/' },
        { focus: 'Infrastructure Design', topics: ['Database Strategy', 'Cloud Transition', 'Connectivity'], link: 'https://roadmap.sh/' },
        { focus: 'Security & Integrity', topics: ['Encryption Protocols', 'Vulnerability Audits', 'Auth'], link: 'https://roadmap.sh/' },
        { focus: 'Performance Engineering', topics: ['Benchmark Analysis', 'Resource Optimization', 'Latency'], link: 'https://roadmap.sh/' },
        { focus: 'System Orchestration', topics: ['CI/CD Integration', 'Production Protocols', 'Maintenance'], link: 'https://roadmap.sh/' },
        { focus: 'Enterprise Standards', topics: ['Professional Documentation', 'Compliance', 'Monitoring'], link: 'https://roadmap.sh/' },
        { focus: 'Full Deployment', topics: ['Production Launch', 'Traffic Orchestration', 'Logging'], link: 'https://roadmap.sh/' },
        { focus: 'System Finalization', topics: ['Strategic Review', 'Lifecycle Planning', 'Optimization Exit'], link: 'https://roadmap.sh/' }
      ],
      'Business & Management': [
        { focus: 'Market Fundamentals', topics: ['Market Principles', 'Organizational Terms', 'Setup'], link: 'https://hbr.org/' },
        { focus: 'Strategic Architecture', topics: ['Planning Logic', 'Execution Flows', 'Structural Mapping'], link: 'https://hbr.org/' },
        { focus: 'Implementation Mastery', topics: ['Service Logic', 'Integration', 'Initial Run'], link: 'https://hbr.org/' },
        { focus: 'Complexity Management', topics: ['Scalability Theory', 'Standardization', 'Scaling'], link: 'https://hbr.org/' },
        { focus: 'KPI Verification', topics: ['Metric Standards', 'Risk Mitigation', 'Quality'], link: 'https://hbr.org/' },
        { focus: 'Stakeholder Design', topics: ['Strategy Connectivity', 'Decision Flow', 'Management'], link: 'https://hbr.org/' },
        { focus: 'Data Integrity', topics: ['Compliance Audits', 'Logic Verification', 'Security'], link: 'https://hbr.org/' },
        { focus: 'Resource Optimization', topics: ['Process Benchmarks', 'Cost Planning', 'Speed'], link: 'https://hbr.org/' },
        { focus: 'System Orchestration', topics: ['Workflow Design', 'Operational Protocols', 'Maintenance'], link: 'https://hbr.org/' },
        { focus: 'Professional Standards', topics: ['Standard Documentation', 'Alignment', 'Monitoring'], link: 'https://hbr.org/' },
        { focus: 'Strategic Launch', topics: ['Market Deployment', 'Orchestration', 'Management'], link: 'https://hbr.org/' },
        { focus: 'System Finalization', topics: ['Assessment', 'Optimization Exit', 'Lifecycle Plan'], link: 'https://hbr.org/' }
      ],
      'Creative & Media': [
        { focus: 'Design Fundamentals', topics: ['Principles', 'Concepts', 'Workspace'], link: 'https://www.behance.net/' },
        { focus: 'Visual Architecture', topics: ['Structural Logic', 'Mapping', 'Initial Design'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Concept Implementation', topics: ['Asset Creation', 'Logic Integration'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Advanced Aesthetics', topics: ['Complexity Control', 'Theory'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Asset Verification', topics: ['Quality Standards', 'Mistake Mitigation'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'System Connectivity', topics: ['Design Strategy', 'Connectivity Logic'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Rights & Integrity', topics: ['Licensing', 'Vulnerability Audits', 'Security'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Benchmark Analysis', topics: ['File Optimization', 'Resource planning'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Creative Orchestration', topics: ['Workflow protocols', 'Delivery Design'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Professional Standards', topics: ['Documentation', 'Alignment', 'Monitoring'], link: 'https://www.adobe.com/creativecloud.html' },
        { focus: 'Portfolio Launch', topics: ['Market Engagement', 'Deployment'], link: 'https://www.behance.net/' },
        { focus: 'Creative Finalization', topics: ['Strategic Review', 'Lifecycle Assessment'], link: 'https://www.behance.net/' }
      ],
      'Student & Exam Paths': [
        { focus: 'Subject foundations', topics: ['Core Concepts', 'Logic Mapping'], link: 'https://www.khanacademy.org/' },
        { focus: 'Syllabus Structural Design', topics: ['Mapping Theory', 'Structural Execution'], link: 'https://www.khanacademy.org/' },
        { focus: 'Technical learning', topics: ['Implementation A', 'Logic Integration'], link: 'https://www.khanacademy.org/' },
        { focus: 'Advanced Subject Theory', topics: ['Complexity Management', 'Scalability'], link: 'https://www.khanacademy.org/' },
        { focus: 'Mock Verification', topics: ['Quality Standards', 'Accuracy Logic'], link: 'https://www.khanacademy.org/' },
        { focus: 'Resource Connectivity', topics: ['Database Strategy', 'Cloud Transition'], link: 'https://www.khanacademy.org/' },
        { focus: 'Academic Integrity', topics: ['Audits', 'Logic Verification'], link: 'https://www.khanacademy.org/' },
        { focus: 'Benchmark Analysis', topics: ['Time Optimization', 'Memory Speed'], link: 'https://www.khanacademy.org/' },
        { focus: 'Revision Orchestration', topics: ['Exam protocols', 'Strategy Design'], link: 'https://www.khanacademy.org/' },
        { focus: 'Subject Documentation', topics: ['Compliance', 'Logic Monitoring'], link: 'https://www.khanacademy.org/' },
        { focus: 'Final Examination Launch', topics: ['Orchestration', 'Log Management'], link: 'https://www.khanacademy.org/' },
        { focus: 'Strategic Review', topics: ['Assessment', 'Optimization Exit'], link: 'https://www.khanacademy.org/' }
      ]
    };

    const syllabus = curriculumLibrary[data.field] || sectorDefaults[data.category] || sectorDefaults['Tech & Engineering'];

    // Construct exactly 12 containers
    return syllabus.slice(0, 12).map((unit, i) => ({
      week: i + 1,
      focus: unit.focus,
      topics: unit.topics,
      link: unit.link,
      status: i === 0 ? 'active' : 'upcoming',
    }));
  };


  const generateDailyTasks = (data, weeklyFocus) => {
    const tasksList = [];
    const dailyMinutes = parseInt(data.dailyTime) || 60;

    // Get topics from the active week
    const activeWeek = weeklyFocus.find(w => w.status === 'active') || weeklyFocus[0];
    const topics = activeWeek.topics;

    // Category-Specific Verbs & Templates
    const templates = {
      'Tech & Engineering': {
        t1: 'Theoretical Deep-Dive: [TOPIC] Architecture',
        t2: 'Technical Execution: Implement [TOPIC] Logic',
        t3: 'System Integration: Connect [TOPIC] to Stack',
        t4: 'Validation: Technical Review & Debugging'
      },
      'Business & Management': {
        t1: 'Strategic Analysis: [TOPIC] Market Study',
        t2: 'Execution Blueprint: Draft [TOPIC] Plan',
        t3: 'Operational Sync: Integrate [TOPIC] Workflows',
        t4: 'Analytics: Review [TOPIC] Performance Metrics'
      },
      'Creative & Media': {
        t1: 'Conceptual Research: [TOPIC] Inspo & Research',
        t2: 'Creative Production: Draft [TOPIC] Assets',
        t3: 'Design Refinement: Polish [TOPIC] Composition',
        t4: 'Aesthetic Review: Critique [TOPIC] Logic'
      },
      'Student & Exam Paths': {
        t1: 'Conceptual Mastery: [TOPIC] Theory & Notes',
        t2: 'Practice Protocol: Solve [TOPIC] Problem Sets',
        t3: 'Retrieval Practice: Active Recall on [TOPIC]',
        t4: 'Mock Simulation: Timed Review of [TOPIC]'
      },
      'Core & Professional': {
        t1: 'Domain Principles: [TOPIC] Theory Study',
        t2: 'Field Application: Practical [TOPIC] Exercise',
        t3: 'Standard Integration: Apply [TOPIC] Norms',
        t4: 'Quality Audit: Standards Review of [TOPIC]'
      },
      'default': {
        t1: 'Foundational Theory: [TOPIC] Principles',
        t2: 'Practical Application: Apply [TOPIC] Concepts',
        t3: 'System Integration: Connect [TOPIC] to Workflow',
        t4: 'Critical Review: Assess [TOPIC] Outcomes'
      }
    };

    const categoryTemplate = templates[data.category] || templates['default'];

    for (let day = 1; day <= 7; day++) {
      const taskList = [];
      const topicIndex = (day - 1) % topics.length;
      const currentTopic = topics[topicIndex];

      // Calculate durations for 4 tasks (30%, 40%, 20%, 10% split)
      const d1 = Math.max(Math.floor(dailyMinutes * 0.3), 5);
      const d2 = Math.max(Math.floor(dailyMinutes * 0.4), 10);
      const d3 = Math.max(Math.floor(dailyMinutes * 0.2), 5);
      const d4 = Math.max(Math.floor(dailyMinutes * 0.1), 5);

      const formatTitle = (tpl, topic, time) => tpl.replace('[TOPIC]', topic) + ` (${time} min)`;

      // 1. Level 1: Theory
      taskList.push({
        id: `task-${day}-1`,
        title: formatTitle(categoryTemplate.t1, currentTopic, d1),
        duration: d1,
        type: 'reading',
        completed: false,
      });

      // 2. Level 2: Practice
      taskList.push({
        id: `task-${day}-2`,
        title: formatTitle(categoryTemplate.t2, currentTopic, d2),
        duration: d2,
        type: 'practice',
        completed: false,
      });

      // 3. Level 3: Project/Recall
      taskList.push({
        id: `task-${day}-3`,
        title: formatTitle(categoryTemplate.t3, currentTopic, d3),
        duration: d3,
        type: 'project',
        completed: false,
      });

      // 4. Level 4: Revision/Audit
      taskList.push({
        id: `task-${day}-4`,
        title: formatTitle(categoryTemplate.t4, currentTopic, d4),
        duration: d4,
        type: 'revision',
        completed: false,
      });

      tasksList.push({
        day: day,
        date: new Date(Date.now() + (day - 1) * 24 * 60 * 60 * 1000).toLocaleDateString(),
        tasks: taskList,
        completed: false,
      });
    }

    return tasksList;
  };

  const generateMilestones = (data) => {
    return [
      { id: 1, title: 'Phase One: Fundamentals', target: 25, status: 'active' },
      { id: 2, title: 'Phase Two: Core Projects', target: 50, status: 'upcoming' },
      { id: 3, title: 'Phase Three: Advanced Skillset', target: 75, status: 'upcoming' },
      { id: 4, title: 'Phase Four: Professional Portfolio', target: 100, status: 'upcoming' },
    ];
  };

  const generateProjects = (data) => {
    const projectsByField = {
      'Frontend Developer': ['Responsive SaaS Dashboard', 'Component Library System', 'Real-time Portfolio'],
      'Backend Developer': ['High-Concurrency Microservices API', 'Distributed Event-Driven Broker', 'Global Data Sync'],
      'Full-Stack Developer': ['E-commerce Platform Architecture', 'Social Media Engine', 'Real-time Analytics Suite'],
      'Mobile App Developer': ['Native iOS/Android Lifecycle App', 'Cross-Platform Banking Suite', 'Offline Navigation System'],
      'DevOps Engineer': ['K8s Cluster Automation', 'Zero-Downtime Pipeline', 'Infrastructure Monitoring Stack'],
      'AI / ML Engineer': ['Neural Network from Scratch', 'Predictive Analysis Model', 'Computer Vision Suite'],
      'Cybersecurity Analyst': ['Penetration Testing Lab', 'Network Intrusion Detection', 'Security Audit Framework'],
      'Data Scientist': ['Predictive Business Model', 'Customer Segmentation Engine', 'Deep Learning Visualizer'],
      'GATE Preparation': ['Subject-wise Previous Year Sets', 'Engineering Math Analytics', 'Full-Length Mock Series'],
      'UPSC Preparation': ['Daily Answer Writing Portfolio', 'General Studies Static Notes', 'Current Affairs Compendium'],
      'School Student (10th)': ['Science Working Model', 'Math Conceptual Portfolio', 'History Timeline Project'],
      'School Student (12th)': ['Class 12 Physics Investigatory', 'Chemistry Analysis Report', 'Math Proof Collection'],
      'Digital Marketing': ['Ad Campaign Launch Strategy', 'SEO Audit Portfolio', 'Content Growth Case Study'],
      'UI / UX Designer': ['Full Mobile App Case Study', 'Design System Architecture', 'Landing Page Suite'],
      'GRE Preparation': ['Quantitative Proof Sets', 'Verbal Analytics Portfolio', 'Full AWA Essay Set'],
      'IELTS Preparation': ['Speaking Section Portfolio', 'Writing Task 1&2 Collection', 'Listening Precision Sets']
    };

    const projects = projectsByField[data.field] || [
      'Standard System Implementation',
      'Advanced Architectural Project',
      'Capstone Research Project',
    ];

    return projects;
  };

  const generateCertifications = (data) => {
    const certsByField = {
      'Frontend Developer': ['Certified Meta Frontend Professional', 'Google Cloud UX Specialization'],
      'Backend Developer': ['AWS Certified Solutions Architect', 'Node.js JSNAD Certification'],
      'Full-Stack Developer': ['AWS Certified Developer - Associate', 'Meta Full-Stack Professional'],
      'Mobile App Developer': ['Google Associate Android Developer', 'Meta iOS Professional'],
      'DevOps Engineer': ['Certified Kubernetes Administrator (CKA)', 'AWS DevOps Engineer Professional'],
      'AI / ML Engineer': ['DeepLearning.AI Machine Learning Specialization', 'Google Professional ML Engineer'],
      'Cybersecurity Analyst': ['CompTIA Security+', 'Certified Ethical Hacker (CEH)'],
      'Data Scientist': ['IBM Data Science Professional', 'Google Professional Data Engineer'],
      'GATE Preparation': ['Official GATE Score Card (Target 700+)', 'IIT-GATE Technical Merit'],
      'UPSC Preparation': ['UPSC Merit Recognition', 'Civil Services Strategy Badge'],
      'School Student (10th)': ['CBSE Board Marksheet Excellence', 'NTSE Scholarship (Target)'],
      'School Student (12th)': ['AISSE Higher Secondary Excellence', 'JEE/NEET Foundation Merit'],
      'UI/UX Designer': ['Google UX Design Professional', 'Interaction Design Foundation (IxDF)'],
      'GRE Preparation': ['Official ETS Score Report (Target 320+)', 'GRE Verbal Mastery Badge'],
      'IELTS Preparation': ['Official British Council/IDP Report (Band 8+)', 'IELTS Academic Merit']
    };
    return certsByField[data.field] || [
      'Industry Professional Validation',
      'Advanced Technical Certification',
    ];
  };

  // Reset application
  const handleReset = () => {
    if (confirm('Verify: Reset all system progress? This action is irreversible.')) {
      localStorage.clear();
      setUserData(null);
      setRoadmapData(null);
      setProgressData({
        streak: 0,
        tasksCompleted: 0,
        xp: 0,
        level: 1,
        completionPercentage: 0,
        weeklyProgress: Array(7).fill(0),
      });
      setCurrentView('welcome');
    }
  };

  return (
    <div className="app">
      {/* Proper Classical Background */}
      <div className="app-background">
        <div className="static-grain"></div>
      </div>

      <div className="app-content">
        {/* Show Auth screens if not logged in */}
        {!currentUser ? (
          <>
            {authView === 'login' && (
              <Login
                onSwitchToSignup={() => setAuthView('signup')}
                onForgotPassword={() => setAuthView('forgot-password')}
              />
            )}

            {authView === 'signup' && (
              <Signup onSwitchToLogin={() => setAuthView('login')} />
            )}

            {authView === 'forgot-password' && (
              <ForgotPassword onBack={() => setAuthView('login')} />
            )}
          </>
        ) : (
          <>
            {/* Main App Content - Only when authenticated */}
            {currentView === 'welcome' && (
              <Welcome onGetStarted={() => setCurrentView('onboarding')} />
            )}

            {currentView === 'onboarding' && (
              <Onboarding onComplete={handleOnboardingComplete} />
            )}

            {currentView === 'dashboard' && userData && roadmapData && (
              <Dashboard
                userData={userData}
                roadmapData={roadmapData}
                progressData={progressData}
                onReset={handleReset}
                setProgressData={setProgressData}
                currentUser={currentUser}
                onLogout={logout}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;
